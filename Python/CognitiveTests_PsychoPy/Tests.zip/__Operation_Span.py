#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.90.1),
    on Thu May 31 16:48:39 2018
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding
import Operation_Span_calculations_maker
import Operation_Span_uebung_calculations_maker
import Operation_Span_ntrial_shuffler
import Operation_Span_uebung_ntrial_shuffler
from getSessionInfo import (session, ID)

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'OperationSpan'  # from the Builder filename that created this script
expInfo = {'participant': ID, 'session': session, 'expName': expName, 'date': data.getDateStr()}

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['session'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0.75,0.75,0.75], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "instr1"
instr1Clock = core.Clock()
instructions1 = visual.ImageStim(
    win=win, name = 'instructions1',
    image='Operation_Span_stimuli/Instruction1.png', mask=None,
    ori = 0, pos=(0, 0), 
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions1.size *= 0.6

# Initialize components for Routine "instr2"
instr2Clock = core.Clock()
instructions2 = visual.ImageStim(
    win=win, name = 'instructions2',
    image='Operation_Span_stimuli/Instruction2.png', mask=None,
    ori = 0, pos=(0, 0), 
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions2.size *= 0.6

# Initialize components for Routine "instr2a"
instr2aClock = core.Clock()
instructions2a = visual.ImageStim(
    win=win, name = 'instructions2a',
    image='Operation_Span_stimuli/Instruction2a.png', mask=None,
    ori = 0, pos=(0, 0), 
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions2a.size *= 0.6

    
# Initialize components for Routine "instr3"
instr3Clock = core.Clock()
instructions3 = visual.ImageStim(
    win=win, name = 'instructions3',
    image='Operation_Span_stimuli/Instruction3.png', mask=None,
    ori = 0, pos=(0, 0), 
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions3.size *= 0.6


# Initialize components for Routine "fixcross_uebung" and "fixcross_real"
fixcrossClock = core.Clock()
cross = visual.TextStim(win=win, name='cross',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "calc"
calcClock = core.Clock()
calculation = visual.TextStim(win=win, name='calculation',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=0.0);
image_keys = visual.ImageStim(
    win=win, name='image_keys', 
    image='Operation_Span_stimuli/buttons_answer.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
image_keys.size *= 0.5

# Initialize components for Routine "letter"
letterClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=0.0);
ISI_letter = clock.StaticPeriod(win=win, screenHz=expInfo['frameRate'], name='ISI_letter')

# Initialize components for Routine "response"
responseClock = core.Clock()
question = visual.TextStim(win=win, name='question',
    text='?',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "feedback"
feedbackClock = core.Clock()

pressed_letter = visual.TextStim(win=win, name='pressed_letter',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=-1.0);

# Initialize components for Routine "thumbs"
thumbsClock = core.Clock()
#msg variable just needs some value at start
msg=''
thumbs = visual.ImageStim(
    win=win, name="feedback",
    image="Operation_Span_stimuli/thumbs-up.png", mask=None,
    ori=0, pos=(0,0.2),
    color=[1,1,1], colorSpace="rgb", opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
thumbs.size *= 0.8
ISI_thumbs = clock.StaticPeriod(win=win, screenHz=expInfo['frameRate'], name='ISI_thumbs')


# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 


# ------Prepare to start Routine "instr1"-------
t = 0
instr1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr1 = event.BuilderKeyResponse()
# keep track of which components have finished
instr1Components = [instructions1]
for thisComponent in instr1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr1"-------
while continueRoutine:
    # get current time
    t = instr1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions1* updates
    if t >= 0.0 and instructions1.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions1.tStart = t
        instructions1.frameNStart = frameN  # exact frame index
        instructions1.setAutoDraw(True)
        
    # *key_instr1* updates
    if t >= 2.0 and key_instr1.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr1.tStart = t
        key_instr1.frameNStart = frameN  # exact frame index
        key_instr1.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr1.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr1"-------
for thisComponent in instr1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2"-------
t = 0
instr2Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr2 = event.BuilderKeyResponse()
# keep track of which components have finished
instr2Components = [instructions2]
for thisComponent in instr2Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr2"-------
while continueRoutine:
    # get current time
    t = instr2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions2* updates
    if t >= 0.0 and instructions2.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions2.tStart = t
        instructions2.frameNStart = frameN  # exact frame index
        instructions2.setAutoDraw(True)
        
    # *key_instr2* updates
    if t >= 2.0 and key_instr2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr2.tStart = t
        key_instr2.frameNStart = frameN  # exact frame index
        key_instr2.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr2.status == STARTED:
        theseKeys = event.getKeys(keyList=['right'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2"-------
for thisComponent in instr2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2"-------
t = 0
instr2aClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr2a = event.BuilderKeyResponse()
# keep track of which components have finished
instr2aComponents = [instructions2a]
for thisComponent in instr2aComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr2a"-------
while continueRoutine:
    # get current time
    t = instr2aClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions2a* updates
    if t >= 0.0 and instructions2a.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions2a.tStart = t
        instructions2a.frameNStart = frameN  # exact frame index
        instructions2a.setAutoDraw(True)
        
    # *key_instr2a* updates
    if t >= 2.0 and key_instr2a.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr2a.tStart = t
        key_instr2a.frameNStart = frameN  # exact frame index
        key_instr2a.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr2a.status == STARTED:
        theseKeys = event.getKeys(keyList=['right', 'u'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if "u" in theseKeys:
            wants_trial = True
        else:
            wants_trial = False
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2aComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2a"-------
for thisComponent in instr2aComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
if wants_trial == True:
    didnt_get_the_task = True # This loop is inserted so that we can repeat the uebung trials, e.g. if participants didn't understand the task. To repeat the uebung, press R after trials uebung.
    while didnt_get_the_task == True:
        block = data.TrialHandler(nReps=1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('Operation_Span_Uebung_Trials_Selection.xlsx'),
            seed=None, name='block')
        thisExp.addLoop(block)  # add the loop to the experiment
        thisBlock = block.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
        if thisBlock != None:
            for paramName in thisBlock:
                exec('{} = thisBlock[paramName]'.format(paramName))

        for thisBlock in block:
            currentLoop = block
            # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
            if thisBlock != None:
                for paramName in thisBlock:
                    exec('{} = thisBlock[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "fixcross_uebung"-------
            t = 0
            fixcrossClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(1.500000)
            # update component parameters for each repeat
            # keep track of which components have finished
            fixcrossComponents = [cross]
            for thisComponent in fixcrossComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "fixcross_uebung"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = fixcrossClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *cross* updates
                if t >= 0.0 and cross.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    cross.tStart = t
                    cross.frameNStart = frameN  # exact frame index
                    cross.setAutoDraw(True)
                frameRemains = 0.0 + 1.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                if cross.status == STARTED and t >= frameRemains:
                    cross.setAutoDraw(False)
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in fixcrossComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "fixcross_uebung"-------
            for thisComponent in fixcrossComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            # set up handler to look after randomisation of conditions etc
            trials = data.TrialHandler(nReps=1, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=data.importConditions('Operation_Span_Uebung_RandomOperationSpan.xlsx', selection=rows),
                seed=None, name='trials')
            thisExp.addLoop(trials)  # add the loop to the experiment
            thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if thisTrial != None:
                for paramName in thisTrial:
                    exec('{} = thisTrial[paramName]'.format(paramName))
            
            for thisTrial in trials:
                currentLoop = trials
                # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
                if thisTrial != None:
                    for paramName in thisTrial:
                        exec('{} = thisTrial[paramName]'.format(paramName))
                
                # ------Prepare to start Routine "calc_uebung"-------
                t = 0
                calcClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                routineTimer.add(5.00000)
                # update component parameters for each repeat
                calculation.setText(operation)
                key_calculation = event.BuilderKeyResponse()
                # keep track of which components have finished
                calcComponents = [calculation, key_calculation, image_keys]
                for thisComponent in calcComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "calc_uebung"-------
                while continueRoutine and routineTimer.getTime() > 0:
                    # get current time
                    t = calcClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *image_keys* updates
                    if t >= 0.0 and image_keys.status == NOT_STARTED:
                    # keep track of start time/frame for later
                        image_keys.tStart = t
                        image_keys.frameNStart = frameN  # exact frame index
                        image_keys.setAutoDraw(True)
                    
                    # *calculation* updates
                    if t >= 0.0 and calculation.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        calculation.tStart = t
                        calculation.frameNStart = frameN  # exact frame index
                        calculation.setAutoDraw(True)
                    frameRemains = 0.0 + 5.0- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if calculation.status == STARTED and t >= frameRemains:
                        calculation.setAutoDraw(False)
                    
                    # *key_calculation* updates
                    if t >= 0.0 and key_calculation.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        key_calculation.tStart = t
                        key_calculation.frameNStart = frameN  # exact frame index
                        key_calculation.status = STARTED
                        # keyboard checking is just starting
                        win.callOnFlip(key_calculation.clock.reset)  # t=0 on next screen flip
                        event.clearEvents(eventType='keyboard')
                    frameRemains = 0.0 + 5.0- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if key_calculation.status == STARTED and t >= frameRemains:
                        key_calculation.status = STOPPED
                    if key_calculation.status == STARTED:
                        theseKeys = event.getKeys(keyList=['left', 'right'])
                        
                        # check for quit:
                        if "escape" in theseKeys:
                            endExpNow = True
                        if len(theseKeys) > 0:  # at least one key was pressed
                            if key_calculation.keys == []:  # then this was the first keypress
                                key_calculation.keys = theseKeys[0]  # just the first key pressed
                                key_calculation.rt = key_calculation.clock.getTime()
                                # was this 'correct'?
                                if (key_calculation.keys == str(corr_key)) or (key_calculation.keys == corr_key):
                                    key_calculation.corr = 1
                                else:
                                    key_calculation.corr = 0
                                continueRoutine  = False
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in calcComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "calc_uebung"-------
                for thisComponent in calcComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # check responses
                if key_calculation.keys in ['', [], None]:  # No response was made
                    key_calculation.keys=None
                    # was no response the correct answer?!
                    if str(corr_key).lower() == 'none':
                       key_calculation.corr = 1  # correct non-response
                    else:
                       key_calculation.corr = 0  # failed to respond (incorrectly)
                # store data for trials (TrialHandler)
                trials.addData('key_calculation.keys',key_calculation.keys)
                trials.addData('key_calculation.corr', key_calculation.corr)
                if key_calculation.keys != None:  # we had a response
                    trials.addData('key_calculation.rt', key_calculation.rt)
                
                # ------Prepare to start Routine "thumbs"-------
                t = 0
                thumbsClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                routineTimer.add(0.800000)
                # update component parameters for each repeat
                if key_calculation.corr == 1:#stored on last run routine
                    msg="Operation_Span_stimuli/thumbs-up.png"
                else:
                    msg = "Operation_Span_stimuli/thumbs-down.png"
                thumbs.setImage(msg)
                # keep track of which components have finished
                thumbsComponents = [thumbs, ISI_thumbs]
                for thisComponent in thumbsComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "thumbs"-------
                while continueRoutine and routineTimer.getTime() > 0:
                    # get current time
                    t = thumbsClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *thumbs* updates
                    if t >= 0.0 and thumbs.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        thumbs.tStart = t
                        thumbs.frameNStart = frameN  # exact frame index
                        thumbs.setAutoDraw(True)
                    frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if thumbs.status == STARTED and t >= frameRemains:
                        thumbs.setAutoDraw(False)
                    # *ISI_thumbs* period
                    if t >= 1.0 and ISI_thumbs.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        ISI_thumbs.tStart = t
                        ISI_thumbs.frameNStart = frameN  # exact frame index
                        ISI_thumbs.start(0.3)
                    elif ISI_thumbs.status == STARTED:  # one frame should pass before updating params and completing
                        ISI_thumbs.complete()  # finish the static period
                        
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in thumbsComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "thumbs"-------
                for thisComponent in thumbsComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                
                # ------Prepare to start Routine "letter_uebung"-------
                t = 0
                letterClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                routineTimer.add(1.100000)
                # update component parameters for each repeat
                text.setText(letter)
                # keep track of which components have finished
                letterComponents = [text, ISI_letter]
                for thisComponent in letterComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "letter_uebung"-------
                while continueRoutine and routineTimer.getTime() > 0:
                    # get current time
                    t = letterClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *text* updates
                    if t >= 0.0 and text.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        text.tStart = t
                        text.frameNStart = frameN  # exact frame index
                        text.setAutoDraw(True)
                    frameRemains = 0.0 + 1.0- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if text.status == STARTED and t >= frameRemains:
                        text.setAutoDraw(False)
                    # *ISI_letter* period
                    if t >= 1.0 and ISI_letter.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        ISI_letter.tStart = t
                        ISI_letter.frameNStart = frameN  # exact frame index
                        ISI_letter.start(0.1)
                    elif ISI_letter.status == STARTED:  # one frame should pass before updating params and completing
                        ISI_letter.complete()  # finish the static period
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in letterComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "letter_uebung"-------
                for thisComponent in letterComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                thisExp.nextEntry()
                
            # completed 1 repeats of 'trials'
            
            
            # set up handler to look after randomisation of conditions etc
            response_letters = data.TrialHandler(nReps=1, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=data.importConditions('Operation_Span_Uebung_RandomOperationSpan.xlsx', selection=rows),
                seed=None, name='response_letters')
            thisExp.addLoop(response_letters)  # add the loop to the experiment
            thisResponse_letter = response_letters.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisResponse_letter.rgb)
            if thisResponse_letter != None:
                for paramName in thisResponse_letter:
                    exec('{} = thisResponse_letter[paramName]'.format(paramName))
            
            for thisResponse_letter in response_letters:
                currentLoop = response_letters
                # abbreviate parameter names if possible (e.g. rgb = thisResponse_letter.rgb)
                if thisResponse_letter != None:
                    for paramName in thisResponse_letter:
                        exec('{} = thisResponse_letter[paramName]'.format(paramName))
                
                # ------Prepare to start Routine "response_uebung"-------
                t = 0
                responseClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                # update component parameters for each repeat
                key_letters = event.BuilderKeyResponse()
                # keep track of which components have finished
                responseComponents = [question, key_letters]
                for thisComponent in responseComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "response_uebung"-------
                while continueRoutine:
                    # get current time
                    t = responseClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *question_uebung* updates
                    if t >= 0.0 and question.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        question.tStart = t
                        question.frameNStart = frameN  # exact frame index
                        question.setAutoDraw(True)
                    
                    # *key_letters* updates
                    if t >= 0.0 and key_letters.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        key_letters.tStart = t
                        key_letters.frameNStart = frameN  # exact frame index
                        key_letters.status = STARTED
                        # keyboard checking is just starting
                        win.callOnFlip(key_letters.clock.reset)  # t=0 on next screen flip
                        event.clearEvents(eventType='keyboard')
                    if key_letters.status == STARTED:
                        theseKeys = event.getKeys(keyList=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'])
                        
                        # check for quit:
                        if "escape" in theseKeys:
                            endExpNow = True
                        if len(theseKeys) > 0:  # at least one key was pressed
                            if key_letters.keys == []:  # then this was the first keypress
                                key_letters.keys = theseKeys[0]  # just the first key pressed
                                key_letters.rt = key_letters.clock.getTime()
                                # was this 'correct'?
                                if (key_letters.keys == str(letter.lower())) or (key_letters.keys == letter.lower()):
                                    key_letters.corr = 1
                                else:
                                    key_letters.corr = 0
                                # a response ends the routine
                                continueRoutine = False
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in responseComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "response_uebung"-------
                for thisComponent in responseComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # check responses
                if key_letters.keys in ['', [], None]:  # No response was made
                    key_letters.keys=None
                    # was no response the correct answer?!
                    if str(letter.lower()).lower() == 'none':
                       key_letters.corr = 1  # correct non-response
                    else:
                       key_letters.corr = 0  # failed to respond (incorrectly)
                # store data for response_letters (TrialHandler)
                response_letters.addData('key_letters.keys',key_letters.keys)
                response_letters.addData('key_letters.corr', key_letters.corr)
                if key_letters.keys != None:  # we had a response
                    response_letters.addData('key_letters.rt', key_letters.rt)
                # the Routine "response" was not non-slip safe, so reset the non-slip timer
                routineTimer.reset()
                
                # ------Prepare to start Routine "feedback"-------
                t = 0
                feedbackClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                routineTimer.add(0.200000)
                # update component parameters for each repeat
                msg = key_letters.keys.upper()
                pressed_letter.setText(msg)
                # keep track of which components have finished
                feedbackComponents = [pressed_letter]
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "feedback"-------
                while continueRoutine and routineTimer.getTime() > 0:
                    # get current time
                    t = feedbackClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    
                    # *pressed_letter* updates
                    if t >= 0.0 and pressed_letter.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        pressed_letter.tStart = t
                        pressed_letter.frameNStart = frameN  # exact frame index
                        pressed_letter.setAutoDraw(True)
                    frameRemains = 0.0 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if pressed_letter.status == STARTED and t >= frameRemains:
                        pressed_letter.setAutoDraw(False)
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in feedbackComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "feedback"-------
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                        
                # ------Prepare to start Routine "thumbs"-------
                t = 0
                thumbsClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                routineTimer.add(0.800000)
                # update component parameters for each repeat
                if key_letters.corr == 1:#stored on last run routine
                    msg="Operation_Span_stimuli/thumbs-up.png"
                else:
                    msg = "Operation_Span_stimuli/thumbs-down.png"
                thumbs.setImage(msg)
                # keep track of which components have finished
                thumbsComponents = [thumbs, ISI_thumbs]
                for thisComponent in thumbsComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "thumbs"-------
                while continueRoutine and routineTimer.getTime() > 0:
                    # get current time
                    t = thumbsClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *thumbs* updates
                    if t >= 0.0 and thumbs.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        thumbs.tStart = t
                        thumbs.frameNStart = frameN  # exact frame index
                        thumbs.setAutoDraw(True)
                    frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if thumbs.status == STARTED and t >= frameRemains:
                        thumbs.setAutoDraw(False)
                    # *ISI_thumbs* period
                    if t >= 1.0 and ISI_thumbs.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        ISI_thumbs.tStart = t
                        ISI_thumbs.frameNStart = frameN  # exact frame index
                        ISI_thumbs.start(0.3)
                    elif ISI_thumbs.status == STARTED:  # one frame should pass before updating params and completing
                        ISI_thumbs.complete()  # finish the static period
                        
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in thumbsComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "thumbs"-------
                for thisComponent in thumbsComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                
                thisExp.nextEntry()
                
            # completed 1 repeats of 'response_letters'
            
        # completed 1 repeats of 'block'

        # ------Prepare to start Routine "instr3"-------
        t = 0
        instr3Clock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        key_instr3 = event.BuilderKeyResponse()
        # keep track of which components have finished
        instr3Components = [instructions3]
        for thisComponent in instr3Components:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED

        # -------Start Routine "instr3"-------
        while continueRoutine:
            # get current time
            t = instr3Clock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *instructions3* updates
            if t >= 0.0 and instructions3.status == NOT_STARTED:
                # keep track of start time/frame for later
                instructions3.tStart = t
                instructions3.frameNStart = frameN  # exact frame index
                instructions3.setAutoDraw(True)
                
            # *key_instr3* updates
            if t >= 2.0 and key_instr3.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_instr3.tStart = t
                key_instr3.frameNStart = frameN  # exact frame index
                key_instr3.status = STARTED
                # keyboard checking is just starting
                event.clearEvents(eventType='keyboard')
            if key_instr3.status == STARTED:
                theseKeys = event.getKeys(keyList=['right', 'r'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    # a response ends the routine
                    key_instr3.keys = theseKeys[-1]
                    if (key_instr3.keys == str('right')) or (key_instr3.keys == 'right'):
                        didnt_get_the_task = False
                    continueRoutine = False
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in instr3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()

        # -------Ending Routine "instr3"-------
        for thisComponent in instr3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "instr" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
############## BEGIN REAL TRIALS #################################################################

# set up handler to look after randomisation of conditions etc
block = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Operation_Span_Trials_Selection.xlsx'),
    seed=None, name='block')
thisExp.addLoop(block)  # add the loop to the experiment
thisBlock = block.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
if thisBlock != None:
    for paramName in thisBlock:
        exec('{} = thisBlock[paramName]'.format(paramName))


for thisBlock in block:
    currentLoop = block
    # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
    if thisBlock != None:
        for paramName in thisBlock:
            exec('{} = thisBlock[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "fixcross_real"-------
    t = 0
    fixcrossClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(1.500000)
    # update component parameters for each repeat
    # keep track of which components have finished
    fixcrossComponents = [cross]
    for thisComponent in fixcrossComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "fixcross_real"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = fixcrossClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *cross* updates
        if t >= 0.0 and cross.status == NOT_STARTED:
            # keep track of start time/frame for later
            cross.tStart = t
            cross.frameNStart = frameN  # exact frame index
            cross.setAutoDraw(True)
        frameRemains = 0.0 + 1.5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if cross.status == STARTED and t >= frameRemains:
            cross.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixcrossComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "fixcross_real"-------
    for thisComponent in fixcrossComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # set up handler to look after randomisation of conditions etc
    trials = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Operation_Span_RandomOperationSpan.xlsx', selection=rows),
        seed=None, name='trials')
    thisExp.addLoop(trials)  # add the loop to the experiment
    thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    for thisTrial in trials:
        currentLoop = trials
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                exec('{} = thisTrial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "calc_real"-------
        t = 0
        calcClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(5.00000)
        # update component parameters for each repeat
        calculation.setText(operation)
        key_calculation = event.BuilderKeyResponse()
        # keep track of which components have finished
        calcComponents = [calculation, key_calculation, image_keys]
        for thisComponent in calcComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "calc_real"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = calcClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_keys* updates
            if t >= 0.0 and image_keys.status == NOT_STARTED:
            # keep track of start time/frame for later
                image_keys.tStart = t
                image_keys.frameNStart = frameN  # exact frame index
                image_keys.setAutoDraw(True)
            
            # *calculation* updates
            if t >= 0.0 and calculation.status == NOT_STARTED:
                # keep track of start time/frame for later
                calculation.tStart = t
                calculation.frameNStart = frameN  # exact frame index
                calculation.setAutoDraw(True)
            frameRemains = 0.0 + 5.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if calculation.status == STARTED and t >= frameRemains:
                calculation.setAutoDraw(False)
            
            # *key_calculation* updates
            if t >= 0.0 and key_calculation.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_calculation.tStart = t
                key_calculation.frameNStart = frameN  # exact frame index
                key_calculation.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_calculation.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            frameRemains = 0.0 + 5.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if key_calculation.status == STARTED and t >= frameRemains:
                key_calculation.status = STOPPED
            if key_calculation.status == STARTED:
                theseKeys = event.getKeys(keyList=['left', 'right'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    if key_calculation.keys == []:  # then this was the first keypress
                        key_calculation.keys = theseKeys[0]  # just the first key pressed
                        key_calculation.rt = key_calculation.clock.getTime()
                        # was this 'correct'?
                        if (key_calculation.keys == str(corr_key)) or (key_calculation.keys == corr_key):
                            key_calculation.corr = 1
                        else:
                            key_calculation.corr = 0
                        continueRoutine = False
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in calcComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "calc_real"-------
        for thisComponent in calcComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_calculation.keys in ['', [], None]:  # No response was made
            key_calculation.keys=None
            # was no response the correct answer?!
            if str(corr_key).lower() == 'none':
               key_calculation.corr = 1  # correct non-response
            else:
               key_calculation.corr = 0  # failed to respond (incorrectly)
        # store data for trials (TrialHandler)
        trials.addData('key_calculation.keys',key_calculation.keys)
        trials.addData('key_calculation.corr', key_calculation.corr)
        if key_calculation.keys != None:  # we had a response
            trials.addData('key_calculation.rt', key_calculation.rt)
        
        # ------Prepare to start Routine "letter_real"-------
        t = 0
        letterClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(1.100000)
        # update component parameters for each repeat
        text.setText(letter)
        # keep track of which components have finished
        letterComponents = [text, ISI_letter]
        for thisComponent in letterComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "letter_real"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = letterClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text* updates
            if t >= 0.0 and text.status == NOT_STARTED:
                # keep track of start time/frame for later
                text.tStart = t
                text.frameNStart = frameN  # exact frame index
                text.setAutoDraw(True)
            frameRemains = 0.0 + 1.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if text.status == STARTED and t >= frameRemains:
                text.setAutoDraw(False)
            # *ISI_letter* period
            if t >= 1.0 and ISI_letter.status == NOT_STARTED:
                # keep track of start time/frame for later
                ISI_letter.tStart = t
                ISI_letter.frameNStart = frameN  # exact frame index
                ISI_letter.start(0.1)
            elif ISI_letter.status == STARTED:  # one frame should pass before updating params and completing
                ISI_letter.complete()  # finish the static period
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in letterComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "letter_real"-------
        for thisComponent in letterComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.nextEntry()
        
    # completed 1 repeats of 'trials'
    
    
    # set up handler to look after randomisation of conditions etc
    response_letters = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('Operation_Span_RandomOperationSpan.xlsx', selection=rows),
        seed=None, name='response_letters')
    thisExp.addLoop(response_letters)  # add the loop to the experiment
    thisResponse_letter = response_letters.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisResponse_letter.rgb)
    if thisResponse_letter != None:
        for paramName in thisResponse_letter:
            exec('{} = thisResponse_letter[paramName]'.format(paramName))
    
    for thisResponse_letter in response_letters:
        currentLoop = response_letters
        # abbreviate parameter names if possible (e.g. rgb = thisResponse_letter.rgb)
        if thisResponse_letter != None:
            for paramName in thisResponse_letter:
                exec('{} = thisResponse_letter[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "response_real"-------
        t = 0
        responseClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        key_letters = event.BuilderKeyResponse()
        # keep track of which components have finished
        responseComponents = [question, key_letters]
        for thisComponent in responseComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "response_real"-------
        while continueRoutine:
            # get current time
            t = responseClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *question* updates
            if t >= 0.0 and question.status == NOT_STARTED:
                # keep track of start time/frame for later
                question.tStart = t
                question.frameNStart = frameN  # exact frame index
                question.setAutoDraw(True)
            
            # *key_letters* updates
            if t >= 0.0 and key_letters.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_letters.tStart = t
                key_letters.frameNStart = frameN  # exact frame index
                key_letters.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_letters.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            if key_letters.status == STARTED:
                theseKeys = event.getKeys(keyList=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    if key_letters.keys == []:  # then this was the first keypress
                        key_letters.keys = theseKeys[0]  # just the first key pressed
                        key_letters.rt = key_letters.clock.getTime()
                        # was this 'correct'?
                        if (key_letters.keys == str(letter.lower())) or (key_letters.keys == letter.lower()):
                            key_letters.corr = 1
                        else:
                            key_letters.corr = 0
                        # a response ends the routine
                        continueRoutine = False
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in responseComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "response_real"-------
        for thisComponent in responseComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_letters.keys in ['', [], None]:  # No response was made
            key_letters.keys=None
            # was no response the correct answer?!
            if str(letter.lower()).lower() == 'none':
               key_letters.corr = 1  # correct non-response
            else:
               key_letters.corr = 0  # failed to respond (incorrectly)
        # store data for response_letters (TrialHandler)
        response_letters.addData('key_letters.keys',key_letters.keys)
        response_letters.addData('key_letters.corr', key_letters.corr)
        if key_letters.keys != None:  # we had a response
            response_letters.addData('key_letters.rt', key_letters.rt)
        # the Routine "response" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "feedback"-------
        t = 0
        feedbackClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(0.200000)
        # update component parameters for each repeat
        msg = key_letters.keys.upper()
        pressed_letter.setText(msg)
        # keep track of which components have finished
        feedbackComponents = [pressed_letter]
        for thisComponent in feedbackComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "feedback"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = feedbackClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *pressed_letter* updates
            if t >= 0.0 and pressed_letter.status == NOT_STARTED:
                # keep track of start time/frame for later
                pressed_letter.tStart = t
                pressed_letter.frameNStart = frameN  # exact frame index
                pressed_letter.setAutoDraw(True)
            frameRemains = 0.0 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
            if pressed_letter.status == STARTED and t >= frameRemains:
                pressed_letter.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "feedback"-------
        for thisComponent in feedbackComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
        thisExp.nextEntry()
        
    # completed 1 repeats of 'response_letters'
    
# completed 1 repeats of 'block'

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
#win.close()
#core.quit()
