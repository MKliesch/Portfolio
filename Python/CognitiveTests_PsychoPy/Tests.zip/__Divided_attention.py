#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.90.1),
    on Tue May  1 11:12:28 2018
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008

"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding
sys.path.append('/Divided_attention_datageneration.py')
import Divided_attention_datageneration
from getSessionInfo import (session, ID)

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'DividedAttention'  # from the Builder filename that created this script
expInfo = {'participant': ID, 'session': session, 'expName': expName, 'date': data.getDateStr()}

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['session'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1440, 900), fullscr=True, screen=0, # THIS IS WHERE I WOULD HAVE TO ADJUST WINDOW SIZE ACCORDING TO COMPUTER ROOM
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0.75,0.75,0.75], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess


########## BIS HIER HIN NICHTS ZU TUN ######################

########## JETZT KOMMEN DIE STIMULI (Punkt + Fadenkreuz) ####################

# Initialize components for Routine "instr1"
instr1Clock = core.Clock()
instructions1 = visual.ImageStim(
    win=win, name = 'instructions1',
    image='Divided_attention_stimuli/Instruction1.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions1.size *= 0.6

# Initialize components for Routine "instr2"
instr2Clock = core.Clock()
instructions2 = visual.ImageStim(
    win=win, name = 'instructions2',
    image='Divided_attention_stimuli/Instruction2.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions2.size *= 0.6

# Initialize components for Routine "trials_uebung"
trials_uebungClock = core.Clock()
scale = 0.4 # Wie viel kleiner/grösser der Punkt/Fadenkreuz als in der Originaldatei sein soll.

image_space_uebung = visual.ImageStim(
    win=win, name='image_space_instr',
    image='Divided_attention_stimuli/space.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_space_uebung.size *= 0.4

stroop_words_uebung = visual.TextStim(win=win, name='stroop_words_uebung', #das conditions file unten einfügen!
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0, 
    color=1.0, colorSpace='rgb', opacity=1,
    depth=0.0);

dot = visual.ImageStim(
    win=win, name='dot',
    image='Divided_attention_stimuli/green_dot.png', mask=None, # WAR VORHIN stimuli/green_dot.png UND HAT FUNKTIONIERT.
    ori=0, pos=(0,0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
#print ("Eben war der Punkt so gross:", dot.size)
dot.size *=scale # Wenn man size in der Klammer definiert, verzerrt es den Punkt.
#print("Jetzt ist der Punkt so gross:", dot.size)

vm = visual.CustomMouse(win,showLimitBox=False)
vm.pointer = visual.ImageStim(win, name = "some_pointer_name", image = "Divided_attention_stimuli/pointer.png")
#print("Eben war das Fadenkreuz noch so gross:", vm.pointer.size)
vm.pointer.size *= scale # Weil ich das Kreuz bisschen kleiner haben will.
#print("Das Fadenkreuz ist gerade so gross:", vm.pointer.size)

# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
#msg variable just needs some value at start
msg=''
feedback = visual.ImageStim(
    win=win, name="feedback",
    image="Divided_attention_stimuli/thumbs-up.png", mask=None,
    ori=0, pos=(0,0),
    color=[1,1,1], colorSpace="rgb", opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
feedback.size *= 0.8

# Initialize components for Routine "instr3"
instr3Clock = core.Clock()
instructions3 = visual.ImageStim(
    win=win, name = 'instructions3',
    image='Divided_attention_stimuli/Instruction3.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions3.size *= 0.6

# Initialize components for Routine "trial_real"
trialClock = core.Clock()
scale = 0.4 # Wie viel kleiner/grösser der Punkt/Fadenkreuz als in der Originaldatei sein soll.

#from psychopy import visual
#win = visual.Window(fullscr=True)

stroop_words = visual.TextStim(win=win, name='stroop_words', #das conditions file unten einfügen!
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=1.0, colorSpace='rgb', opacity=1,
    depth=0.0);

dot = visual.ImageStim(
    win=win, name='dot',
    image='Divided_attention_stimuli/green_dot.png', mask=None, # WAR VORHIN stimuli/green_dot.png UND HAT FUNKTIONIERT.
    ori=0, pos=(0,0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
#print ("Eben war der Punkt so gross:", dot.size)
dot.size *=scale # Wenn man size in der Klammer definiert, verzerrt es den Punkt.
#print("Jetzt ist der Punkt so gross:", dot.size)

vm = visual.CustomMouse(win,showLimitBox=False)
vm.pointer = visual.ImageStim(win, name = "some_pointer_name", image = "Divided_attention_stimuli/pointer.png")
#print("Eben war das Fadenkreuz noch so gross:", vm.pointer.size)
vm.pointer.size *= scale # Weil ich das Kreuz bisschen kleiner haben will.
#print("Das Fadenkreuz ist gerade so gross:", vm.pointer.size)

image_space_real = visual.ImageStim(
    win=win, name='image_space_real',
    image='Divided_attention_stimuli/space.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
image_space_real.size *= 0.4

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instr1"-------
t = 0
instr1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr1 = event.BuilderKeyResponse()
# keep track of which components have finished
instr1Components = [instructions1]
for thisComponent in instr1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr1"-------
while continueRoutine:
    # get current time
    t = instr1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions1* updates
    if t >= 0.0 and instructions1.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions1.tStart = t
        instructions1.frameNStart = frameN  # exact frame index
        instructions1.setAutoDraw(True)
        
    # *key_instr1* updates
    if t >= 2.0 and key_instr1.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr1.tStart = t
        key_instr1.frameNStart = frameN  # exact frame index
        key_instr1.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr1.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr1"-------
for thisComponent in instr1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2"-------
t = 0
instr2Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr2 = event.BuilderKeyResponse()
# keep track of which components have finished
instr2Components = [instructions2]
for thisComponent in instr2Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr"-------
while continueRoutine:
    # get current time
    t = instr2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions2* updates
    if t >= 0.0 and instructions2.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions2.tStart = t
        instructions2.frameNStart = frameN  # exact frame index
        instructions2.setAutoDraw(True)
        
    # *key_instr2* updates
    if t >= 2.0 and key_instr2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr2.tStart = t
        key_instr2.frameNStart = frameN  # exact frame index
        key_instr2.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr2.status == STARTED:
        theseKeys = event.getKeys(keyList=['space', 'u'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if "u" in theseKeys:
            wants_trial = True
        else:
            wants_trial = False
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2"-------
for thisComponent in instr2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
if wants_trial == True:
    didnt_get_the_task = True # This loop is inserted so that we can repeat the uebung trials, e.g. if participants didn't understand the task. To repeat the uebung, press R after trials uebung.
    while didnt_get_the_task == True:
        trials = data.TrialHandler(nReps=1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            #trialList=positions_table, # DAS IST DER SELBERGEMACHTE VEKTOR
            trialList = data.importConditions('Divided_attention_fixed_trials.xlsx'), # that was when we took it from the Excel
            seed=None, name='trials')
        thisExp.addLoop(trials)  # add the loop to the experiment
        thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
        #print(trials.trialList)
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                exec('{} = thisTrial[paramName]'.format(paramName))

        for thisTrial in trials:
            currentLoop = trials
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if thisTrial != None:
                for paramName in thisTrial:
                    exec('{} = thisTrial[paramName]'.format(paramName))

            # ------Prepare to start Routine "trial_uebung"-------
            t = 0
            trials_uebungClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.000000)
            # update component parameters for each repeat
            dot.setPos(position) # Picking a dot position from the vector/file
            stroop_words_uebung.setColor(colour, colorSpace='rgb')
            stroop_words_uebung.setText(word)
            key_words_uebung = event.BuilderKeyResponse()
            gruene_toleranzDistanz = vm.pointer.size * 0.1
            gelbe_toleranzDistanz = vm.pointer.size * 0.5
            
            # setup some python lists for storing info about the mouse
            gotValidClick = False  # until a click is received
            mouse_response_uebung = event.Mouse(win = win, visible = False)
            x, y = [None,None]
            # keep track of which components have finished
            trials_uebungComponents = [dot, mouse_response_uebung, key_words_uebung, stroop_words_uebung]
            for thisComponent in trials_uebungComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "trials_uebung"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = trials_uebungClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame

                # *vm* updates
                if t >= 0.0 and mouse_response_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    mouse_response_uebung.tStart = t
                    mouse_response_uebung.frameNStart = frameN  # exact frame index
                    event.clearEvents(eventType='mouse')
                    vm.draw()
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if mouse_response_uebung.status == STARTED and t >= frameRemains:
                    mouse_response_uebung.status = STOPPED

                # *dot* updates
                if t >= 0.0 and dot.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    dot.tStart = t
                    dot.frameNStart = frameN  # exact frame index
                    dot.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if dot.status == STARTED and t <=frameRemains:
                    x,y = mouse_response_uebung.getPos() # I need to get it from here for the following if-condition.
                    if (x > dot.pos[0] + gelbe_toleranzDistanz[0]) | (x < dot.pos[0] - gelbe_toleranzDistanz[0]) | (y < dot.pos[1] - gelbe_toleranzDistanz[1]) | (y > dot.pos[1] + gelbe_toleranzDistanz[1]):
                        dot.setImage('Divided_attention_stimuli/red_dot.png')
                    elif ((x < dot.pos[0] + gelbe_toleranzDistanz[0]) & (x > dot.pos[0] + gruene_toleranzDistanz[0])) | ((x > dot.pos[0] - gelbe_toleranzDistanz[0]) & (x < dot.pos[0] - gruene_toleranzDistanz[0])) | ((y < dot.pos[1] + gelbe_toleranzDistanz[1]) & (y > dot.pos[1] + gruene_toleranzDistanz[1])) | ((y > dot.pos[1] - gelbe_toleranzDistanz[1]) & (y < dot.pos[1] - gruene_toleranzDistanz[1])):
                        dot.setImage('Divided_attention_stimuli/yellow_dot.png')
                    else:
                        dot.setImage('Divided_attention_stimuli/green_dot.png')
                if dot.status == STARTED and t >= frameRemains:
                    dot.setAutoDraw(False)
                
                # *stroop_words_uebung* updates
                if t >= 0.0 and stroop_words_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    stroop_words_uebung.tStart = t
                    stroop_words_uebung.frameNStart = frameN  # exact frame index
                    stroop_words_uebung.setAutoDraw(True)
                frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
                if stroop_words_uebung.status == STARTED and t >= frameRemains:
                    stroop_words_uebung.setAutoDraw(False)
                
                # *key_words_uebung* updates
                if t >= 0.0 and key_words_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    key_words_uebung.tStart = t
                    key_words_uebung.frameNStart = frameN  # exact frame index
                    key_words_uebung.status = STARTED
                    # keyboard checking is just starting
                    win.callOnFlip(key_words_uebung.clock.reset)  # t=0 on next screen flip
                    event.clearEvents(eventType='keyboard')
                frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
                if key_words_uebung.status == STARTED and t >= frameRemains:
                    key_words_uebung.status = STOPPED
                if key_words_uebung.status == STARTED:
                    theseKeys = event.getKeys(keyList=['space', 'none'])
                    
                    # check for quit:
                    if "escape" in theseKeys:
                        endExpNow = True
                    if len(theseKeys) > 0:  # at least one key was pressed
                        if key_words_uebung.keys == []:  # then this was the first keypress
                            key_words_uebung.keys = theseKeys[0]  # just the first key pressed
                            key_words_uebung.rt = key_words_uebung.clock.getTime()
                            # was this 'correct'?
                            if (key_words_uebung.keys == str(corr_key)) or (key_words_uebung.keys == corr_key):
                                key_words_uebung.corr = 1
                            else:
                                key_words_uebung.corr = 0
                                 
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trials_uebungComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "trials_uebung"-------
            for thisComponent in trials_uebungComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            if (x > dot.pos[0] + gelbe_toleranzDistanz[0]) | (x < dot.pos[0] - gelbe_toleranzDistanz[0]) | (y < dot.pos[1] - gelbe_toleranzDistanz[1]) | (x > dot.pos[0] + gelbe_toleranzDistanz[1]):
                mouse_corr = 0
            else:
                mouse_corr = 1
            
           # check responses for stroop
            if key_words_uebung.keys in ['', [], None]:  # No response was made
                key_words_uebung.keys=None
                # was no response the correct answer?!
                if str(corr_key).lower() == 'none':
                   key_words_uebung.corr = 1  # correct non-response
                else:
                   key_words_uebung.corr = 0  # failed to respond (incorrectly)
           # store data for stroop (TrialHandler)
            if key_words_uebung.keys != None:  # we had a response
                thisExp.addData('key_words_uebung.rt', key_words_uebung.rt)

        # ------Prepare to start Routine "feedback"-------
            t = 0
            feedbackClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(0.500000)
            # update component parameters for each repeat
            if key_words_uebung.corr == 1 and key_words_uebung.keys == "space":#stored on last run routine
                msg="Divided_attention_stimuli/thumbs-up.png"
            elif key_words_uebung.corr == 0:
                msg="Divided_attention_stimuli/thumbs-down.png"
            else:
                msg = "Divided_attention_stimuli/empty.png"
            feedback.setImage(msg)
            # keep track of which components have finished
            feedbackComponents = [feedback]
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "feedback"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = feedbackClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                
                # *feedback* updates
                if t >= 0.0 and feedback.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    feedback.tStart = t
                    feedback.frameNStart = frameN  # exact frame index
                    feedback.setAutoDraw(True)
                frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                if feedback.status == STARTED and t >= frameRemains:
                    feedback.setAutoDraw(False)
                    
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "feedback"-------
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            # store data for trials_uebung (TrialHandler)
            thisExp.addData('mouse_pos_uebung.corr', mouse_corr)
            thisExp.addData('mouse_uebung.x', x)
            thisExp.addData('mouse_uebung.y', y)
            thisExp.addData("key_words_uebung.keys", key_words_uebung.keys)
            thisExp.addData("key_words_uebung.corr", key_words_uebung.corr)
            thisExp.nextEntry()

        # ------Prepare to start Routine "instr3"-------
        t = 0
        instr3Clock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        key_instr3 = event.BuilderKeyResponse()
        # keep track of which components have finished
        instr3Components = [instructions3]
        for thisComponent in instr3Components:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED

        # -------Start Routine "instr3"-------
        while continueRoutine:
            # get current time
            t = instr3Clock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *instructions3* updates
            if t >= 0.0 and instructions3.status == NOT_STARTED:
                # keep track of start time/frame for later
                instructions3.tStart = t
                instructions3.frameNStart = frameN  # exact frame index
                instructions3.setAutoDraw(True)
                
            # *key_instr3* updates
            if t >= 2.0 and key_instr3.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_instr3.tStart = t
                key_instr3.frameNStart = frameN  # exact frame index
                key_instr3.status = STARTED
                # keyboard checking is just starting
                event.clearEvents(eventType='keyboard')
            if key_instr3.status == STARTED:
                theseKeys = event.getKeys(keyList=['space', 'r'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    # a response ends the routine
                    key_instr3.keys = theseKeys[-1]
                    if (key_instr3.keys == str('space')) or (key_instr3.keys == 'space'):
                        didnt_get_the_task = False
                    continueRoutine = False
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in instr3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()

        # -------Ending Routine "instr3"-------
        for thisComponent in instr3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "instr" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()

######################## Starting real trials!! ######################################################

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    #trialList=positions_table, # DAS IST DER SELBERGEMACHTE VEKTOR
    trialList = data.importConditions('Divided_attention_myRandomTrials.xlsx'), # that was when we took it from the Excel
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
#print(trials.trialList)
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))

    # ------Prepare to start Routine "trial_real"-------
    t = 0
    trialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    dot.setPos(position) # Picking a dot position from the vector/file
    stroop_words.setColor(colour, colorSpace='rgb')
    stroop_words.setText(word)
    key_words = event.BuilderKeyResponse()
    gruene_toleranzDistanz = vm.pointer.size * 0.1
    gelbe_toleranzDistanz = vm.pointer.size * 0.5
    
    # setup some python lists for storing info about the mouse
    gotValidClick = False  # until a click is received
    mouse_response = event.Mouse(win = win, visible = False)
    x, y = [None,None]
    # keep track of which components have finished
    trialComponents = [dot, mouse_response, key_words, stroop_words] #stroop_words, key_words einfügen
    for thisComponent in trialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trial"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = trialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame

        # *vm* updates
        if t >= 0.0 and mouse_response.status == NOT_STARTED:
            # keep track of start time/frame for later
            mouse_response.tStart = t
            mouse_response.frameNStart = frameN  # exact frame index
            event.clearEvents(eventType='mouse')
            vm.draw()
        frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if mouse_response.status == STARTED and t >= frameRemains:
            mouse_response.status = STOPPED

        # *dot* updates
        if t >= 0.0 and dot.status == NOT_STARTED:
            # keep track of start time/frame for later
            dot.tStart = t
            dot.frameNStart = frameN  # exact frame index
            dot.setAutoDraw(True)
        frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if dot.status == STARTED and t <=frameRemains:
            x,y = mouse_response.getPos() # I need to get it from here for the following if-condition.
            if (x > dot.pos[0] + gelbe_toleranzDistanz[0]) | (x < dot.pos[0] - gelbe_toleranzDistanz[0]) | (y < dot.pos[1] - gelbe_toleranzDistanz[1]) | (y > dot.pos[1] + gelbe_toleranzDistanz[1]):
                dot.setImage('Divided_attention_stimuli/red_dot.png')
            elif ((x < dot.pos[0] + gelbe_toleranzDistanz[0]) & (x > dot.pos[0] + gruene_toleranzDistanz[0])) | ((x > dot.pos[0] - gelbe_toleranzDistanz[0]) & (x < dot.pos[0] - gruene_toleranzDistanz[0])) | ((y < dot.pos[1] + gelbe_toleranzDistanz[1]) & (y > dot.pos[1] + gruene_toleranzDistanz[1])) | ((y > dot.pos[1] - gelbe_toleranzDistanz[1]) & (y < dot.pos[1] - gruene_toleranzDistanz[1])):
                dot.setImage('Divided_attention_stimuli/yellow_dot.png')
            else:
                dot.setImage('Divided_attention_stimuli/green_dot.png')
        if dot.status == STARTED and t >= frameRemains:
            dot.setAutoDraw(False)
        
        # *stroop_words* updates
        if t >= 0.0 and stroop_words.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroop_words.tStart = t
            stroop_words.frameNStart = frameN  # exact frame index
            stroop_words.setAutoDraw(True)
        frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
        if stroop_words.status == STARTED and t >= frameRemains:
            stroop_words.setAutoDraw(False)
        
        # *key_words* updates
        if t >= 0.0 and key_words.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_words.tStart = t
            key_words.frameNStart = frameN  # exact frame index
            key_words.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_words.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
        if key_words.status == STARTED and t >= frameRemains:
            key_words.status = STOPPED
        if key_words.status == STARTED:
            theseKeys = event.getKeys(keyList=['space', 'none'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                if key_words.keys == []:  # then this was the first keypress
                    key_words.keys = theseKeys[0]  # just the first key pressed
                    key_words.rt = key_words.clock.getTime()
                    # was this 'correct'?
                    if (key_words.keys == str(corr_key)) or (key_words.keys == corr_key):
                        key_words.corr = 1
                    else:
                        key_words.corr = 0
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trial"-------
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    if (x > dot.pos[0] + gelbe_toleranzDistanz[0]) | (x < dot.pos[0] - gelbe_toleranzDistanz[0]) | (y < dot.pos[1] - gelbe_toleranzDistanz[1]) | (x > dot.pos[0] + gelbe_toleranzDistanz[1]):
        mouse_corr = 0
    else:
        mouse_corr = 1
    
   # check responses for stroop
    if key_words.keys in ['', [], None]:  # No response was made
        key_words.keys=None
        # was no response the correct answer?!
        if str(corr_key).lower() == 'none':
           key_words.corr = 1  # correct non-response
        else:
           key_words.corr = 0  # failed to respond (incorrectly)
   # store data for stroop (TrialHandler)
    if key_words.keys != None:  # we had a response
        thisExp.addData('key_words.rt', key_words.rt)
    
    #store data for overall score
    if mouse_corr == 0 or key_words.corr == 0:
        overallscore = 0
    else: 
        overallscore = 1
    
    # store data for trials (TrialHandler)
    thisExp.addData('mouse_pos.corr', mouse_corr)
    thisExp.addData('mouse.x', x)
    thisExp.addData('mouse.y', y)
    thisExp.addData("key_words.keys", key_words.keys)
    thisExp.addData("key_words.corr", key_words.corr)
    thisExp.addData("overall.corr", overallscore)
    thisExp.nextEntry()
    
# completed 1 repeats of 'trials'

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
#win.close()
#core.quit()
