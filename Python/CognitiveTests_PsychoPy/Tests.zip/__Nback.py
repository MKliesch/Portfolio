#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.90.0),
    on May 30, 2018, at 20:38
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding
import Nback_datageneration
from getSessionInfo import (session, ID)

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'NBack'  # from the Builder filename that created this script
expInfo = {'participant': ID, 'session': session, 'expName': expName, 'date': data.getDateStr()}

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['session'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0.75,0.75,0.75], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "instr1"
instr1Clock = core.Clock()
instructions1 = visual.ImageStim(
    win=win, name = 'instructions1',
    image='Nback_stimuli/Instruction1.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions1.size *= 0.6

# Initialize components for Routine "instr2"
instr2Clock = core.Clock()
instructions2 = visual.ImageStim(
    win=win, name = 'instructions2',
    image='Nback_stimuli/Instruction2.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions2.size *= 0.6
    
# Initialize components for Routine "instr3"
instr3Clock = core.Clock()
instructions3 = visual.ImageStim(
    win=win, name = 'instructions3',
    image='Nback_stimuli/Instruction3.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions3.size *= 0.6

# Initialize components for Routine "trials_uebung"
trials_uebungClock = core.Clock()
letters_uebung = visual.TextStim(win=win, name='letters_uebung',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=0.0);

image_key_uebung = visual.ImageStim(
    win=win, name='image_key_uebung',
    image='Nback_stimuli/Key_down.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key_uebung.size *= 0.1

# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
#msg variable just needs some value at start
msg=''
feedback = visual.ImageStim(
    win=win, name="feedback",
    image="Nback_stimuli/thumbs-up.png", mask=None,
    ori=0, pos=(0,0),
    color=[1,1,1], colorSpace="rgb", opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
feedback.size *= 0.8

# Initialize components for Routine "trials_real"
trials_realClock = core.Clock()
letters_real = visual.TextStim(win=win, name='letters_real',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color=[-0.125, -0.125, -0.125], colorSpace='rgb', opacity=1,
    depth=0.0);

image_key_real = visual.ImageStim(
    win=win, name='image_key_real',
    image='Nback_stimuli/Key_down.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key_real.size *= 0.1

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instr1"-------
t = 0
instr1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr1 = event.BuilderKeyResponse()
# keep track of which components have finished
instr1Components = [instructions1]
for thisComponent in instr1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr1"-------
while continueRoutine:
    # get current time
    t = instr1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions1* updates
    if t >= 0.0 and instructions1.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions1.tStart = t
        instructions1.frameNStart = frameN  # exact frame index
        instructions1.setAutoDraw(True)
        
    # *key_instr1* updates
    if t >= 2.0 and key_instr1.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr1.tStart = t
        key_instr1.frameNStart = frameN  # exact frame index
        key_instr1.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr1.status == STARTED:
        theseKeys = event.getKeys(keyList=['down'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr1"-------
for thisComponent in instr1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2"-------
t = 0
instr2Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr2 = event.BuilderKeyResponse()
# keep track of which components have finished
instr2Components = [instructions2]
for thisComponent in instr2Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr"-------
while continueRoutine:
    # get current time
    t = instr2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions2* updates
    if t >= 0.0 and instructions2.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions2.tStart = t
        instructions2.frameNStart = frameN  # exact frame index
        instructions2.setAutoDraw(True)
        
    # *key_instr2* updates
    if t >= 2.0 and key_instr2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr2.tStart = t
        key_instr2.frameNStart = frameN  # exact frame index
        key_instr2.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr2.status == STARTED:
        theseKeys = event.getKeys(keyList=['down', 'u'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if "u" in theseKeys:
            wants_trial = True
        else:
            wants_trial = False
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2"-------
for thisComponent in instr2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
if wants_trial == True:
    didnt_get_the_task = True # This loop is inserted so that we can repeat the uebung trials, e.g. if participants didn't understand the task. To repeat the uebung, press R after trials uebung.
    while didnt_get_the_task == True:
        loop_uebung = data.TrialHandler(nReps=1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('Nback_fixed_trials.xlsx'),
            seed=None, name='loop_uebung')
        thisExp.addLoop(loop_uebung)  # add the loop to the experiment
        thisLoop_uebung = loop_uebung.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisLoop_uebung.rgb)
        if thisLoop_uebung != None:
            for paramName in thisLoop_uebung:
                exec('{} = thisLoop_uebung[paramName]'.format(paramName))

        for thisLoop_uebung in loop_uebung:
            currentLoop = loop_uebung
            # abbreviate parameter names if possible (e.g. rgb = thisLoop_uebung.rgb)
            if thisLoop_uebung != None:
                for paramName in thisLoop_uebung:
                    exec('{} = thisLoop_uebung[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "trials_uebung"-------
            t = 0
            trials_uebungClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.500000)
            # update component parameters for each repeat
            letters_uebung.setText(letter)
            key_uebung = event.BuilderKeyResponse()
            # keep track of which components have finished
            trials_uebungComponents = [letters_uebung, key_uebung, image_key_uebung]
            for thisComponent in trials_uebungComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "trials_uebung"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = trials_uebungClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *letters_uebung* updates
                if t >= 0.0 and letters_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    letters_uebung.tStart = t
                    letters_uebung.frameNStart = frameN  # exact frame index
                    letters_uebung.setAutoDraw(True)
                frameRemains = 0.0 + 1.5 - win.monitorFramePeriod * 0.75  # most of one frame period left
                if letters_uebung.status == STARTED and t >= frameRemains:
                    letters_uebung.setAutoDraw(False)
                    
                # *image_key_uebung* updates
                if t >= 0.0 and image_key_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    image_key_uebung.tStart = t
                    image_key_uebung.frameNStart = frameN  # exact frame index
                    image_key_uebung.setAutoDraw(True)
                
                # *key_uebung* updates
                if t >= 0.0 and key_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    key_uebung.tStart = t
                    key_uebung.frameNStart = frameN  # exact frame index
                    key_uebung.status = STARTED
                    # keyboard checking is just starting
                    win.callOnFlip(key_uebung.clock.reset)  # t=0 on next screen flip
                frameRemains = 0.0 + 2.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                if key_uebung.status == STARTED and t >= frameRemains:
                    key_uebung.status = STOPPED
                if key_uebung.status == STARTED:
                    theseKeys = event.getKeys(keyList=['down', ''])
                    
                    # check for quit:
                    if "escape" in theseKeys:
                        endExpNow = True
                    if len(theseKeys) > 0:  # at least one key was pressed
                        if key_uebung.keys == []:  # then this was the first keypress
                            key_uebung.keys = theseKeys[0]  # just the first key pressed
                            key_uebung.rt = key_uebung.clock.getTime()
                            # was this 'correct'?
                            if (key_uebung.keys == str(button)) or (key_uebung.keys == button):
                                key_uebung.corr = 1
                            else:
                                key_uebung.corr = 0
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trials_uebungComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "trials_uebung"-------
            for thisComponent in trials_uebungComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_uebung.keys in ['', [], None]:  # No response was made
                key_uebung.keys=None
                # was no response the correct answer?!
                if str(button).lower() == 'none':
                   key_uebung.corr = 1  # correct non-response
                else:
                   key_uebung.corr = 0  # failed to respond (incorrectly)
            # store data for loop_uebung (TrialHandler)
            loop_uebung.addData('key_uebung.keys',key_uebung.keys)
            loop_uebung.addData('key_uebung.corr', key_uebung.corr)
            if key_uebung.keys != None:  # we had a response
                loop_uebung.addData('key_uebung.rt', key_uebung.rt)
            
        # ------Prepare to start Routine "feedback"-------
            t = 0
            feedbackClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(0.500000)
            # update component parameters for each repeat
            if key_uebung.corr == 1 and key_uebung.keys == "down":#stored on last run routine
                msg="Nback_stimuli/thumbs-up.png"
            elif key_uebung.corr == 0:
                msg="Nback_stimuli/thumbs-down.png"
            else:
                msg = "Nback_stimuli/empty.png"
            feedback.setImage(msg)
            # keep track of which components have finished
            feedbackComponents = [feedback, image_key_uebung]
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "feedback"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = feedbackClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_key_uebung* updates
                if t >= 0.0 and image_key_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    image_key_uebung.tStart = t
                    image_key_uebung.frameNStart = frameN  # exact frame index
                    image_key_uebung.setAutoDraw(True)
                
                # *feedback* updates
                if t >= 0.0 and feedback.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    feedback.tStart = t
                    feedback.frameNStart = frameN  # exact frame index
                    feedback.setAutoDraw(True)
                frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                if feedback.status == STARTED and t >= frameRemains:
                    feedback.setAutoDraw(False)
                    
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "feedback"-------
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            thisExp.nextEntry()
            
        # completed 1 repeats of 'loop_uebung'

        # ------Prepare to start Routine "instr3"-------
        t = 0
        instr3Clock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        key_instr3 = event.BuilderKeyResponse()
        # keep track of which components have finished
        instr3Components = [instructions3]
        for thisComponent in instr3Components:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED

        # -------Start Routine "instr3"-------
        while continueRoutine:
            # get current time
            t = instr3Clock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *instructions3* updates
            if t >= 0.0 and instructions3.status == NOT_STARTED:
                # keep track of start time/frame for later
                instructions3.tStart = t
                instructions3.frameNStart = frameN  # exact frame index
                instructions3.setAutoDraw(True)
                
            # *key_instr3* updates
            if t >= 2.0 and key_instr3.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_instr3.tStart = t
                key_instr3.frameNStart = frameN  # exact frame index
                key_instr3.status = STARTED
                # keyboard checking is just starting
                event.clearEvents(eventType='keyboard')
            if key_instr3.status == STARTED:
                theseKeys = event.getKeys(keyList=['down', 'r'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    # a response ends the routine
                    key_instr3.keys = theseKeys[-1]
                    if (key_instr3.keys == str('down')) or (key_instr3.keys == 'down'):
                        didnt_get_the_task = False
                    continueRoutine = False
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in instr3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()

        # -------Ending Routine "instr3"-------
        for thisComponent in instr3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "instr" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()

###################### Starting real trials!! ###################################

# set up handler to look after randomisation of conditions etc
loop_real = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Nback_datageneration.xlsx'),
    seed=None, name='loop_real')
thisExp.addLoop(loop_real)  # add the loop to the experiment
thisLoop_real = loop_real.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoop_real.rgb)
if thisLoop_real != None:
    for paramName in thisLoop_real:
        exec('{} = thisLoop_real[paramName]'.format(paramName))

for thisLoop_real in loop_real:
    currentLoop = loop_real
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_real.rgb)
    if thisLoop_real != None:
        for paramName in thisLoop_real:
            exec('{} = thisLoop_real[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "trials_real"-------
    t = 0
    trials_realClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(2.500000)
    # update component parameters for each repeat
    letters_real.setText(letter)
    key_real = event.BuilderKeyResponse()
    # keep track of which components have finished
    trials_realComponents = [letters_real, key_real, image_key_real]
    for thisComponent in trials_realComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trials_real"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = trials_realClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *letters_real* updates
        if t >= 0.0 and letters_real.status == NOT_STARTED:
            # keep track of start time/frame for later
            letters_real.tStart = t
            letters_real.frameNStart = frameN  # exact frame index
            letters_real.setAutoDraw(True)
        frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if letters_real.status == STARTED and t >= frameRemains:
            letters_real.setAutoDraw(False)
            
        # *image_key_real* updates
        if t >= 0.0 and image_key_real.status == NOT_STARTED:
            # keep track of start time/frame for later
            image_key_real.tStart = t
            image_key_real.frameNStart = frameN  # exact frame index
            image_key_real.setAutoDraw(True)
            
        # *key_real* updates
        if t >= 0.0 and key_real.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_real.tStart = t
            key_real.frameNStart = frameN  # exact frame index
            key_real.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_real.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + 2.5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if key_real.status == STARTED and t >= frameRemains:
            key_real.status = STOPPED
        if key_real.status == STARTED:
            theseKeys = event.getKeys(keyList=['down', ''])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                if key_real.keys == []:  # then this was the first keypress
                    key_real.keys = theseKeys[0]  # just the first key pressed
                    key_real.rt = key_real.clock.getTime()
                    # was this 'correct'?
                    if (key_real.keys == str(button)) or (key_real.keys == button):
                        key_real.corr = 1
                    else:
                        key_real.corr = 0
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trials_realComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trials_real"-------
    for thisComponent in trials_realComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_real.keys in ['', [], None]:  # No response was made
        key_real.keys=None
        # was no response the correct answer?!
        if str(button).lower() == 'none':
           key_real.corr = 1  # correct non-response
        else:
           key_real.corr = 0  # failed to respond (incorrectly)
    # store data for loop_real (TrialHandler)
    loop_real.addData('key_real.keys',key_real.keys)
    loop_real.addData('key_real.corr', key_real.corr)
    if key_real.keys != None:  # we had a response
        loop_real.addData('key_real.rt', key_real.rt)
    thisExp.nextEntry()
    
# completed 1 repeats of 'loop_real'

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
#win.close()
#core.quit()
