import random
from operator import add, sub
import string
from openpyxl import Workbook

wb = Workbook()
#grab active worksheet
ws= wb.active

#headers

ws['A1'] = "operation"
ws['B1'] = "corr_key"
ws['C1'] = "letter"
ws['D1'] = "answer_letter"



calculations = []
random_letters = []
correct_key = []
correct_nonres = []
count_reps = []
num_items = []
correctness = ['correct','wrong']
all_letters = "BCDFGHJKLMNPRSTVWXZ"

reps_list = [2,3,2,4]
ops = (add,sub)

for i in range(len(reps_list)):
    #count_reps
    for k in range(reps_list[i]):
        bad_one = 1
        while bad_one == 1:
            op = random.choice(ops)
            if op == add:
                Vorzeichen = "+"
            else:
                Vorzeichen = "-"
            num1, num2 = random.randint(1,20), random.randint(1,20)
            random_correct = random.choice(correctness)
            result = op(num1, num2)
            if random_correct == 'correct':
                if result >= 1 and result <= 20:
                    random_calc = str(num1) + Vorzeichen + str(num2) + '=' + str(result)
                    calculations.append(random_calc)
                    correct_key.append("right")
                    letter = random.choice(all_letters)
                    random_letters.append(letter)
                    correct_nonres.append("None")
                    bad_one = 0
                else:
                    bad_one = 1
            else:
                wrong_result = random.randint(1,20)
                if (wrong_result == result) or (result <1) or (result > 20):
                    bad_one = 1
                else:
                    random_calc = str(num1) + Vorzeichen + str(num2) + '=' + str(wrong_result)
                    #print(random_calc)
                    calculations.append(random_calc)
                    #print(calculations)
                    correct_key.append("left")
                    letter = random.choice(all_letters)
                    #print(letter)
                    random_letters.append(letter)
                    #print(random_letters)
                    correct_nonres.append("None")
                    bad_one = 0


row = 2
column = 1

for i in calculations:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

row = 2
column = 2

for i in correct_key:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

row = 2
column = 3

for i in random_letters:
    ws.cell(column= column, row=row, value=str(i))
    row += 1

row = 2
column = 4

for i in correct_nonres:
    ws.cell(column= column, row=row, value=str(i))
    row += 1

wb.save("Operation_Span_Uebung_RandomOperationSpan.xlsx")


