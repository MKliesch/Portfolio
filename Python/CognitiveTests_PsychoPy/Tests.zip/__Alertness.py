from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding
from getSessionInfo import (session, ID)

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'Alertness'  # from the Builder filename that created this script
expInfo = {'participant': ID, 'session': session, 'expName': expName, 'date': data.getDateStr()}

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['session'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0.75,0.75,0.75], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "instr1"
instr1Clock = core.Clock()
instructions1 = visual.ImageStim(
    win=win, name = 'instructions1',
    image='Alertness_stimuli/Instruction1.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions1.size *= 0.6

# Initialize components for Routine "instr2"
instr2Clock = core.Clock()
instructions2 = visual.ImageStim(
    win=win, name = 'instructions2',
    image='Alertness_stimuli/Instruction2.png', mask=None,
    ori = 0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
instructions2.size *= 0.6

# Initialize components for Routine "trials_uebung"
trials_uebungClock = core.Clock()
fixation_uebung = visual.ImageStim(
    win=win, name='fixation_uebung',units='cm', 
    image='Alertness_stimuli/square_grey.jpg', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
cross_uebung = visual.ImageStim(
    win=win, name='cross_uebung',units='cm', 
    image='Alertness_stimuli/cross.png', mask=None,
    ori=0, pos=(0, 0), size=(3, 3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
fixation_uebung_after = visual.ImageStim(
    win=win, name='fixation_uebung_after', units='cm',
    image='Alertness_stimuli/square_grey.jpg', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key_uebung = visual.ImageStim(
    win=win, name='image_key_uebung',
    image='Alertness_stimuli/Key_down.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key_uebung.size *= 0.1


# Initialize components for Routine "trials_real"
trials_realClock = core.Clock()
fixation_real = visual.ImageStim(
    win=win, name='fixation_uebung',units='cm', 
    image='Alertness_stimuli/square_grey.jpg', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
cross_real = visual.ImageStim(
    win=win, name='cross_uebung',units='cm', 
    image='Alertness_stimuli/cross.png', mask=None,
    ori=0, pos=(0, 0), size=(3, 3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
fixation_real_after = visual.ImageStim(
    win=win, name='fixation_real_after', units='cm',
    image='Alertness_stimuli/square_grey.jpg', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key_real = visual.ImageStim(
    win=win, name='image_key_real', 
    image='Alertness_stimuli/Key_down.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key_real.size *= 0.1

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instr1"-------
t = 0
instr1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instr1 = event.BuilderKeyResponse()
# keep track of which components have finished
instr1Components = [instructions1]
for thisComponent in instr1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr1"-------
while continueRoutine:
    # get current time
    t = instr1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructions1* updates
    if t >= 0.0 and instructions1.status == NOT_STARTED:
        # keep track of start time/frame for later
        instructions1.tStart = t
        instructions1.frameNStart = frameN  # exact frame index
        instructions1.setAutoDraw(True)
        
    # *key_instr1* updates
    if t >= 2.0 and key_instr1.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instr1.tStart = t
        key_instr1.frameNStart = frameN  # exact frame index
        key_instr1.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_instr1.status == STARTED:
        theseKeys = event.getKeys(keyList=['down'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr1"-------
for thisComponent in instr1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()


# set up handler to look after randomisation of conditions etc
real = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Alertness_time_condition.xlsx'),
    seed=None, name='real')
thisExp.addLoop(real)  # add the loop to the experiment
thisReal = real.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisReal.rgb)
if thisReal != None:
    for paramName in thisReal:
        exec('{} = thisReal[paramName]'.format(paramName))

for thisReal in real:
    currentLoop = real
    # abbreviate parameter names if possible (e.g. rgb = thisReal.rgb)
    if thisReal != None:
        for paramName in thisReal:
            exec('{} = thisReal[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "trials_real"-------
    t = 0
    trials_realClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    key_down_real = event.BuilderKeyResponse()
    # keep track of which components have finished
    trials_realComponents = [fixation_real, cross_real, fixation_real_after, key_down_real]
    for thisComponent in trials_realComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trials_real"-------
    while continueRoutine:
        # get current time
        t = trials_realClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *fixation_real* updates
        if t >= 0.0 and fixation_real.status == NOT_STARTED:
            # keep track of start time/frame for later
            fixation_real.tStart = t
            fixation_real.frameNStart = frameN  # exact frame index
            fixation_real.setAutoDraw(True)
        if frameN == 0:
            frameRemains = 0.0 + jitter- win.monitorFramePeriod * 0.75  # most of one frame period left
        else:
            frameRemains = 0.0 + jitter - 1.2 - win.monitorFramePeriod * 0.75
        if fixation_real.status == STARTED and t >= frameRemains:
            fixation_real.setAutoDraw(False)
        
        # *cross_real* updates
        if frameN == 0:
            if t >= jitter and cross_real.status == NOT_STARTED:
                # keep track of start time/frame for later
                cross_real.tStart = t
                cross_real.frameNStart = frameN  # exact frame index
                cross_real.setAutoDraw(True)
            frameRemains = jitter + 0.3- win.monitorFramePeriod * 0.75  # most of one frame period left
            if cross_real.status == STARTED and t >= frameRemains:
                cross_real.setAutoDraw(False)
        else: 
            if t >= jitter - 1.2 and cross_real.status == NOT_STARTED:
                # keep track of start time/frame for later
                cross_real.tStart = t
                cross_real.frameNStart = frameN  # exact frame index
                cross_real.setAutoDraw(True)
            frameRemains = jitter - 1.2 + 0.3- win.monitorFramePeriod * 0.75  # most of one frame period left
            if cross_real.status == STARTED and t >= frameRemains:
                cross_real.setAutoDraw(False)
        
        # *fixation_real_after* updates
        if t >= postStim - 1.2 and fixation_real_after.status == NOT_STARTED:
            # keep track of start time/frame for later
            fixation_real_after.tStart = t
            fixation_real_after.frameNStart = frameN  # exact frame index
            fixation_real_after.setAutoDraw(True)
        frameRemains = postStim + 1.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if fixation_real_after.status == STARTED and t >= frameRemains:
            fixation_real_after.setAutoDraw(False)
        
        # *key_down_real* updates
        if frameN == 0:
            if t >= jitter and key_down_real.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_down_real.tStart = t
                key_down_real.frameNStart = frameN  # exact frame index
                key_down_real.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_down_real.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
        else:
            if t >= jitter - 1.2 and key_down_real.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_down_real.tStart = t
                key_down_real.frameNStart = frameN  # exact frame index
                key_down_real.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_down_real.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
        frameRemains = jitter + 1.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if key_down_real.status == STARTED and t >= frameRemains:
            key_down_real.status = STOPPED
        if key_down_real.status == STARTED:
            theseKeys = event.getKeys(keyList=['down'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                if key_down_real.keys == []:  # then this was the first keypress
                    key_down_real.keys = theseKeys[0]  # just the first key pressed
                    key_down_real.rt = key_down_real.clock.getTime()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trials_realComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trials_real"-------
    for thisComponent in trials_realComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_down_real.keys in ['', [], None]:  # No response was made
        key_down_real.keys=None
        key_down_real.corr = 0
    real.addData('key_down_real.keys',key_down_real.keys)
    if key_down_real.keys != None:  # we had a response
        key_down_real.corr = 1
        real.addData('key_down_real.rt', key_down_real.rt)
    real.addData('key_down_real.corr', key_down_real.corr)
    # the Routine "trials_real" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'real'

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
#win.close()
#core.quit()