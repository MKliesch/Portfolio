# This script forms group from the trials made in Operation_Span_calculations_maker.py, such that there are n blocks of n trials
# Example: We want 8 blocks of different length: reps_list = [2, 3, 3, 4, 4, 5, 5, 6]
# The total number of trials is created in Operation_Span_calculations_maker.py
# Here we only group the trials.

import random
from openpyxl import Workbook
from Operation_Span_uebung_calculations_maker import reps_list # Import the trial constellation

wb = Workbook()
#grab active worksheet
ws= wb.active

#headers

ws['A1'] = "rows"

#random.shuffle(reps_list)
row_list = []

# e.g. reps_list = [3,4,2]
# 1:3
# 4:7
# 8:9

for i in range(len(reps_list)):
    this_string = ''
    this_string = this_string + str(sum(reps_list[:i])) + ':' + str(sum(reps_list[:i]) + reps_list[i])
    row_list.append(this_string)


row = 2
column = 1

for i in row_list:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

wb.save("Operation_Span_Uebung_Trials_Selection.xlsx")
