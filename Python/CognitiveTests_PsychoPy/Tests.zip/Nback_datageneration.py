#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This script creates a list of random trials that fulfill the conditions
# of the n-back task and saves it into an xlsx file.

import numpy as np  # whole numpy lib is available, prepend 'np.'
import random # Das richtige Paket laden fr Funktion random.choice
from openpyxl import Workbook

# Create the Excel sheet
wb = Workbook()
ws1 = wb.create_sheet("Stimuli",0)
column_headers = ['letter', 'target_list', 'condition', 'button']
for i in range(1,len(column_headers)+1):
    ws1.cell(column = i, row = 1, value = column_headers[i-1])

stimuli = ['b', 'c', 'd', 'h', 'k', 'p', 'q', 't', 'w']
final_list = [] 
final_string = "" #all letters in a row, no more groups
length_string = 70
correctness_list = [] # indicating 1 for target, 0 for non-target
condition_list = [] # giving a name to the condition
button_list = [] # which button to press per condition



# 20% are targets (B d B / b D B / B D B ...)
# 80% are non-targets
# 2 trials are foils (k c C (non-target), c c C (target))
# Total: approximately 70 trials

def make_randLett(stimuli):
    random_letter = random.choice(stimuli) # pick any letter of the alphabet
    return random_letter

def make_randCaps(letter):
    choice = [letter.lower(),letter.upper()]
    letter = random.choice(choice)
    return letter

def find_allowed(already_picked_letters, all_possible_letters):
    still_allowed = []
    for i in range(len(all_possible_letters)):
        the_ith_letter = all_possible_letters[i]
        upper_case = the_ith_letter.upper()
        if (the_ith_letter not in already_picked_letters) and (upper_case not in already_picked_letters) :
            still_allowed.append(the_ith_letter)
    return still_allowed

#def repeat_to_length(string_to_expand, length):
#    return (string_to_expand * (int(length/len(string_to_expand))+1))[:length]
# Creating a list of target sequences, e.g. 'tPt', 'wcW'
target_list = [] # The final list of targets I want to have
for i in range(0,int(round(length_string * 0.2))-1): # Creating only as many targets as 20 % of the overall number of repetitions; minus one, because 1 is a correct foil
    target_pair = make_randCaps(make_randLett(stimuli)) # first letter is random
    still_allowed_stimuli = find_allowed(target_pair[0], stimuli)
    target_pair = target_pair + make_randCaps(make_randLett(still_allowed_stimuli)) 
    target_pair = target_pair + make_randCaps(target_pair[0])  # third letter is same as first, but may be other capitalization
    target_list.append(target_pair)

# Creating a random false foil (i.e. two same letters after one another)

foil_false = make_randCaps(make_randLett(stimuli))
foil_false = foil_false + make_randCaps(foil_false[0])
false_foil_list = []
false_foil_list.append(foil_false)

# Creating a random correct foil (i.e. three same letters after one another)

foil_corr = make_randCaps(make_randLett(stimuli))
foil_corr = foil_corr + make_randCaps(foil_corr[0])
foil_corr = foil_corr + make_randCaps(foil_corr[0])

corr_foil_list = []
corr_foil_list.append(foil_corr)


### Assembling the final vector by filling it up with random letters

# putting all fixed conditions into one list
fixed_conditions = []
fixed_conditions.extend(false_foil_list + corr_foil_list + target_list) 

used_up_nOfSigns = 2 + 3 + 3 * (round(length_string * 0.2) -1) -1
# 2 stands for the false foil
# 3 stands for the corr foil
# the bracket calculates the number of signs in the correct pairs
# the first minus 1 subtracts the correct foil from the correct pairs
# the last minus 1 subtracts 1 letter, because the first letter is fixed.

# adding random letters that should not repeat the previous one, the one two before, the one after or the one two after
random_As = list('A' * int(length_string - used_up_nOfSigns-1)) # minus one because the first letter has to be fixed
nOfOverallItems = 1 + 1 + len(target_list) + len(random_As) # 1 for the wrong foil, 1 for the correct foil

while len(final_list) < 2: # Can be any number lower than the overall number of letters
    all_shuffled = fixed_conditions + random_As # Create a random combination of As and the conditions
    random.shuffle(all_shuffled) # shuffle the conditions
    for i in range(len(all_shuffled)): # check each position in the combination to see if no 2 conditions appear after one another
        if ((all_shuffled[i] != 'A') and ((all_shuffled[i-1] or all_shuffled[i+1]) != 'A')) or (all_shuffled[0] != 'A'):
            bad_one = 1
            break
        elif all_shuffled[i] != 'A' and i < len(all_shuffled)-2:
            if all_shuffled[i][-1] == all_shuffled[i+2][0]:
                bad_one = 1
                break
        else:
            bad_one = 0
    if bad_one == 1:
        continue
    else:
        while 'A' in all_shuffled: #Change the 'A's to actual letters from the possible stimuli list
            next_ones = []
            for q in range(len(all_shuffled[1])): # No if-condition, because we know that the first one is an A.
                next_ones.append(all_shuffled[1][q])
            still_allowed = find_allowed(next_ones, stimuli)
            all_shuffled[0] = make_randCaps(make_randLett(still_allowed))
            if all_shuffled[1] == 'A': # Writing the second letter if it is an A.
                previous_ones = []
                next_ones = []
                previous_ones.append(all_shuffled[0])
                for q in range(len(all_shuffled[2])):
                    next_ones.append(all_shuffled[2][q])
                all_nogos = previous_ones + next_ones
                still_allowed = find_allowed(all_nogos, stimuli)
                all_shuffled[1] = make_randCaps(make_randLett(still_allowed))
            for l in range(2,len(all_shuffled)):
                if (all_shuffled[l] == 'A') and (l < (len(all_shuffled)-2)):
                    previous_ones = []
                    next_ones = []
                    for m in range(len(all_shuffled[l-1])):
                        previous_ones.append(all_shuffled[l-1][m])
                    for o in range(len(all_shuffled[l-2])):
                        previous_ones.append(all_shuffled[l-2][o])
                    for p in range(len(all_shuffled[l+1])):
                        next_ones.append(all_shuffled[l+1][p])
                    for q in range(len(all_shuffled[l+2])):
                        next_ones.append(all_shuffled[l+2][q])
                    all_nogos = previous_ones + next_ones
                    still_allowed = find_allowed(all_nogos, stimuli)
                    all_shuffled[l] = make_randCaps(make_randLett(still_allowed))
                elif all_shuffled[l] == 'A' and l == (len(all_shuffled)-2):
                    previous_ones = []
                    next_ones = []
                    for m in range(len(all_shuffled[l-1])):
                        previous_ones.append(all_shuffled[l-1][m])
                    for o in range(len(all_shuffled[l-2])):
                        previous_ones.append(all_shuffled[l-2][o])
                    for p in range(len(all_shuffled[l+1])):
                        next_ones.append(all_shuffled[l+1][p])
                    all_nogos = previous_ones + next_ones
                    still_allowed = find_allowed(all_nogos, stimuli)
                    all_shuffled[l] = make_randCaps(make_randLett(still_allowed))
                elif all_shuffled[l] == 'A' and l == (len(all_shuffled)-1):
                    previous_ones = []
                    next_ones = []
                    for m in range(len(all_shuffled[l-1])):
                        previous_ones.append(all_shuffled[l-1][m])
                    for o in range(len(all_shuffled[l-2])):
                        previous_ones.append(all_shuffled[l-2][o])
                    all_nogos = previous_ones + next_ones
                    still_allowed = find_allowed(all_nogos, stimuli)
                    all_shuffled[l] = make_randCaps(make_randLett(still_allowed))
    final_list = final_list + all_shuffled
    for a in range(len(final_list)):
        if len(final_list[a]) == 3:
            correctness_list.append('001')
            for b in range(len(final_list[a])):
                if b == 2:
                    button_list.append('down')
                    condition_list.append('target')
                else:
                    button_list.append('none')
                    condition_list.append('neutral')
        elif len(final_list[a]) == 2:
            correctness_list.append('00')
            for b in range(len(final_list[a])):
                button_list.append('none')
                condition_list.append('neutral')
        else:
            correctness_list.append('0')
            condition_list.append('neutral')
            button_list.append('none')

final_string = ''.join(final_list)
correctness_string = ''.join(correctness_list)

# Writing everything into Excel-sheet

for row in range(len(final_string)):
    ws1.cell(column = 1, row = row+2, value = final_string[row])
    ws1.cell(column = 2, row = row+2, value = correctness_string[row])
    ws1.cell(column = 3, row = row+2, value = condition_list[row])
    ws1.cell(column = 4, row = row+2, value = button_list[row])

wb.save('Nback_datageneration.xlsx')