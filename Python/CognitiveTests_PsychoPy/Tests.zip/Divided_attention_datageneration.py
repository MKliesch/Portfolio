#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import random # Das richtige Paket laden fr Funktion random.choice
#import xlsxwriter
import matplotlib.pyplot as plt

from openpyxl import Workbook

wb = Workbook()
#grab active worksheet
ws= wb.active

column_headers = ['empty','position', 'word', 'colour', 'congruency', 'corr_key']
for i in range(1,len(column_headers)+1):
    ws.cell(column = i, row = 1, value = column_headers[i-1])


n_rep = 60 # Wie viele Trials das Experiment haben soll.


### Define possible and impossible coordinates

def space_fun(low,up,leng): # A function that can space equally also using floats
    list = []
    step = (up - low) / float(leng)
    for i in range(leng):
        list.append(low)
        low = low + step
    return list

whole_coord_range = space_fun(-1, 1, 40) # all coordinates that are possible
whole_coord_range = [ round(elem,2) for elem in whole_coord_range ]
#print('all numbers rounded:',whole_coord_range)

forbidden_range = space_fun(-0.3,0.3, 12) # defining the positions that are not allowed
#forbidden_range = space_fun(-0.3,0.3, 12) # defining the positions that are not allowed

forbidden_range = [ round(elem,2) for elem in forbidden_range ]
#print('all forbidden numbers rounded:', forbidden_range)


positions = ( # We always want to start in the same spot
	[0,0.3],
)

#plt.figure()

old_x = 0.3
old_y = -0


while len(positions) < n_rep:
	x = random.choice(whole_coord_range)
	y = random.choice(whole_coord_range)
	if ((x not in forbidden_range) or (y not in forbidden_range)) and (x < (old_x + 0.4) and x <= 0.9) and (x > (old_x - 0.4) and x >= -0.9) and (y < (old_y + 0.4) and y <= 0.9) and (y > (old_y - 0.4) and y >= -0.9):
		string_to_be = [float(x),float(y)]
		positions = positions + (str(string_to_be),)
		old_x = x
		old_y = y
		#plt.scatter(old_x,old_y)


##### Stroop #############

all_words = ["rot", "grün", "blau"]
all_colours = ["red",'green', 'blue']
congruency = []
words = []
colour = []
corr_key = []
w = ""
c = ""
w_old = ""
c_old = ""

while len(words) < n_rep:
    w = random.choice(all_words)
    c = random.choice(all_colours)
    if (w == w_old) and (c == c_old):
        i = i + 1
        continue
    if w == "rot" and c == "red":
        congr = 1
        k = "space"
    elif w == "grün" and c == "green":
        congr = 1
        k = "space"
    elif w == "blau" and c == "blue":
        congr = 1
        k = "space"
    else:
        congr = 0
        k = "None"
    w_old = w
    c_old = c
    congruency.append(congr)
    words.append(w)
    colour.append(c)
    corr_key.append(k)


#write to Excel-File

row = 2
column = 2

for i in positions:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

row = 2
column = 3

for i in words:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

row = 2
column = 4

for i in colour:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

row = 2
column = 5

for i in congruency:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

row = 2
column = 6

for i in corr_key:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

wb.save("Divided_attention_myRandomTrials.xlsx")