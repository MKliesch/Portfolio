# This script creates a random selection of picture pairs according to the GoNoGo-paradigm of Kropotov 2009 and Tereshchenko 2016.

import numpy as np  # whole numpy lib is available, prepend 'np.'
import random # Das richtige Paket laden fr Funktion random.choice
from openpyxl import Workbook

# Create the Excel sheet
wb = Workbook()
ws1 = wb.create_sheet("Stimuli",0)
column_headers = ['picture', 'category', 'condition', 'congruency','button']
for i in range(1,len(column_headers)+1):
    ws1.cell(column = i, row = 1, value = column_headers[i-1])
    

# Import possible stimuli

anim_pics = ['anim_1.jpg', 'anim_2.jpg', 'anim_3.jpg', 'anim_4.jpg', 'anim_5.jpg']
plant_pics = ['plant_1.jpg', 'plant_2.jpg', 'plant_3.jpg', 'plant_4.jpg', 'plant_5.jpg']
hum_pics = ['hum_1.jpg', 'hum_2.jpg', 'hum_3.jpg', 'hum_4.jpg', 'hum_5.jpg']

# Possible combinations
A_or_P = ['A', 'P']
A_combos = ['A', 'P']
P_combos = ['P', 'H']

# Empty vectors
total_length = 50 # number of pairs, so half the number of stimuli
pics_list = []
cat_list = []
cond_list = []
cong_list = []
button_list = []

# Actual script
for i in range(total_length):
    pos1 = random.choice(A_or_P)
    cond1 = 'nogo'
    cong1 = 0
    button1 = 'None'
    if pos1 == 'A':
        pic1 = random.choice(anim_pics)
        pos2 = random.choice(A_combos)
        if pos2 == 'A':
            pic2 = random.choice(anim_pics)
            while pic2 == pic1:
                pic2 = random.choice(anim_pics)
            cond2 = 'go'
            cong2 = 1
            button2 = 'down'
        else:
            pic2 = random.choice(plant_pics)
            cond2 = 'Nogo'
            cong2 = 0
            button2 = 'None'
    else:
        cond2 = 'nogo'
        cong2 = 0
        button2 = 'None'
        pic1 = random.choice(plant_pics)
        pos2 = random.choice(P_combos)
        if pos2 == 'P':
            pic2 = random.choice(plant_pics)
            while pic2 == pic1:
                pic2 = random.choice(plant_pics)
        else:
            pic2 = random.choice(hum_pics)
    cat_list.append(pos1)
    cat_list.append(pos2)
    pics_list.append(pic1)
    pics_list.append(pic2)
    cond_list.append(cond1)
    cond_list.append(cond2)
    cong_list.append(cong1)
    cong_list.append(cong2)
    button_list.append(button1)
    button_list.append(button2)

for row in range(len(cat_list)):
    ws1.cell(column = 1, row = row+2, value = pics_list[row])
    ws1.cell(column = 2, row = row+2, value = cat_list[row])
    ws1.cell(column = 3, row = row+2, value = cond_list[row])
    ws1.cell(column = 4, row = row+2, value = cong_list[row])
    ws1.cell(column = 5, row = row+2, value = button_list[row])

wb.save('GoNoGo_datageneration.xlsx')

### Block maker ### 
# Create the Excel sheet
wb = Workbook()
ws = wb.create_sheet("Blocks",0)
column_headers = ['rows']
for i in range(1,len(column_headers)+1):
    ws.cell(column = i, row = 1, value = column_headers[i-1])

block_list = [] # going to be just 2s for as many trials as there are
row_list = [] # giving the exact row number for as many trials as there are

for i in range(total_length):
    block_list.append(2)

for i in range(len(block_list)):
    this_string = ''
    this_string = this_string + str(sum(block_list[:i])) + ':' + str(sum(block_list[:i]) + block_list[i])
    row_list.append(this_string)

row = 2
column = 1

for i in row_list:
    ws.cell(column=column, row=row, value=str(i))
    row += 1

wb.save('GoNoGo_blocks.xlsx')