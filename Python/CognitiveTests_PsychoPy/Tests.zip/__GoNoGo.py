#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.90.1),
    on Tue Jul 17 12:03:17 2018
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding
import GoNoGo_datageneration
from getSessionInfo import (session, ID)


# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'GoNoGo'  # from the Builder filename that created this script
expInfo = {'participant': ID, 'session': session, 'expName': expName, 'date': data.getDateStr()}

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['session'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0.75,0.75,0.75], colorSpace='rgb',
    blendMode='avg', useFBO=True)

# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "instr1"
instr1Clock = core.Clock()
image_instruction1 = visual.ImageStim(
    win=win, name='image_instruction1',
    image=u'GoNoGo_stimuli/instruction1.png', mask=None,
    ori=0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_instruction1.size *= 0.6

# Initialize components for Routine "instr2"
instr2Clock = core.Clock()
image_instruction2 = visual.ImageStim(
    win=win, name='image_instruction2',
    image=u'GoNoGo_stimuli/instruction2.png', mask=None,
    ori=0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_instruction2.size *= 0.6

# Initialize components for Routine "stim_uebung"
stim_uebungClock = core.Clock()
pic_uebung = visual.ImageStim(
    win=win, name='pic_uebung',
    image='GoNoGo_stimuli/plant_1.jpg', mask=None,
    ori=0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
pic_uebung.size *= 0.5

image_key = visual.ImageStim(
    win=win, name='image_key',
    image='GoNoGo_stimuli/key_down.png', mask=None,
    ori=0, pos=(0, -0.8),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_key.size *= 0.1


# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
#msg variable just needs some value at start
msg=''
feedback = visual.ImageStim(
    win=win, name="feedback",
    image="GoNoGo_stimuli/thumbs-up.png", mask=None,
    ori=0, pos=(0,0),
    color=[1,1,1], colorSpace="rgb", opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
feedback.size *= 0.8

# Initialize components for Routine "intertr_pause_uebung"
intertr_pause_uebungClock = core.Clock()

# Initialize components for Routine "instr3"
instr3Clock = core.Clock()
image_instruction3 = visual.ImageStim(
    win=win, name='image_instruction3',
    image='GoNoGo_stimuli/instruction3.png', mask=None,
    ori=0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
image_instruction3.size *= 0.7

# Initialize components for Routine "stim_real"
stim_realClock = core.Clock()
pic_real = visual.ImageStim(
    win=win, name='pic_real',
    image='GoNoGo_stimuli/plant_1.jpg', mask=None,
    ori=0, pos=(0, 0),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
pic_real.size *= 0.5


	# Initialize components for Routine "intertr_pause_real"
intertr_pause_realClock = core.Clock()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instr1"-------
t = 0
instr1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instruction1 = event.BuilderKeyResponse()
# keep track of which components have finished
instr1Components = [key_instruction1, image_instruction1]
for thisComponent in instr1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr1"-------
while continueRoutine:
    # get current time
    t = instr1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *key_instruction1* updates
    if t >= 2.0 and key_instruction1.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instruction1.tStart = t
        key_instruction1.frameNStart = frameN  # exact frame index
        key_instruction1.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_instruction1.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_instruction1.status == STARTED:
        theseKeys = event.getKeys(keyList=['down'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            key_instruction1.keys = theseKeys[-1]  # just the last key pressed
            key_instruction1.rt = key_instruction1.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # *image_instruction1* updates
    if t >= 0.0 and image_instruction1.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_instruction1.tStart = t
        image_instruction1.frameNStart = frameN  # exact frame index
        image_instruction1.setAutoDraw(True)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr1"-------
for thisComponent in instr1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_instruction1.keys in ['', [], None]:  # No response was made
    key_instruction1.keys=None
thisExp.addData('key_instruction1.keys',key_instruction1.keys)
if key_instruction1.keys != None:  # we had a response
    thisExp.addData('key_instruction1.rt', key_instruction1.rt)
thisExp.nextEntry()
# the Routine "instr1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2"-------
t = 0
instr2Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_instruction2 = event.BuilderKeyResponse()
# keep track of which components have finished
instr2Components = [key_instruction2, image_instruction2]
for thisComponent in instr2Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr2"-------
while continueRoutine:
    # get current time
    t = instr2Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *key_instruction2* updates
    if t >= 2.0 and key_instruction2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_instruction2.tStart = t
        key_instruction2.frameNStart = frameN  # exact frame index
        key_instruction2.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_instruction2.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if key_instruction2.status == STARTED:
        theseKeys = event.getKeys(keyList=['down', 'u'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if "u" in theseKeys:
            wants_trial = True
        else:
            wants_trial = False
        if len(theseKeys) > 0:  # at least one key was pressed
            key_instruction2.keys = theseKeys[-1]  # just the last key pressed
            key_instruction2.rt = key_instruction2.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # *image_instruction2* updates
    if t >= 0.0 and image_instruction2.status == NOT_STARTED:
        # keep track of start time/frame for later
        image_instruction2.tStart = t
        image_instruction2.frameNStart = frameN  # exact frame index
        image_instruction2.setAutoDraw(True)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2"-------
for thisComponent in instr2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_instruction2.keys in ['', [], None]:  # No response was made
    key_instruction2.keys=None
thisExp.addData('key_instruction2.keys',key_instruction2.keys)
if key_instruction2.keys != None:  # we had a response
    thisExp.addData('key_instruction2.rt', key_instruction2.rt)
thisExp.nextEntry()
# the Routine "instr2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
if wants_trial == True:
    didnt_get_the_task = True # This loop is inserted so that we can repeat the uebung trials, e.g. if participants didn't understand the task. To repeat the uebung, press R after trials uebung.
    while didnt_get_the_task == True:
        pairs_uebung = data.TrialHandler(nReps=1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('GoNoGo_blocks_uebung.xlsx'),
            seed=None, name='pairs_uebung')
        thisExp.addLoop(pairs_uebung)  # add the loop to the experiment
        thisPairs_uebung = pairs_uebung.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisPairs_uebung.rgb)
        if thisPairs_uebung != None:
            for paramName in thisPairs_uebung:
                exec('{} = thisPairs_uebung[paramName]'.format(paramName))

        for thisPairs_uebung in pairs_uebung:
            currentLoop = pairs_uebung
            # abbreviate parameter names if possible (e.g. rgb = thisPairs_uebung.rgb)
            if thisPairs_uebung != None:
                for paramName in thisPairs_uebung:
                    exec('{} = thisPairs_uebung[paramName]'.format(paramName))
            
            # set up handler to look after randomisation of conditions etc
            trial_uebung = data.TrialHandler(nReps=1, method='sequential', 
                extraInfo=expInfo, originPath=-1,
                trialList=data.importConditions('GoNoGo_datageneration_uebung.xlsx', selection=rows),
                seed=None, name='trial_uebung')
            thisExp.addLoop(trial_uebung)  # add the loop to the experiment
            thisTrial_uebung = trial_uebung.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_uebung.rgb)
            if thisTrial_uebung != None:
                for paramName in thisTrial_uebung:
                    exec('{} = thisTrial_uebung[paramName]'.format(paramName))
            
            for thisTrial_uebung in trial_uebung:
                currentLoop = trial_uebung
                # abbreviate parameter names if possible (e.g. rgb = thisTrial_uebung.rgb)
                if thisTrial_uebung != None:
                    for paramName in thisTrial_uebung:
                        exec('{} = thisTrial_uebung[paramName]'.format(paramName))
                
                # ------Prepare to start Routine "stim_uebung"-------
                t = 0
                stim_uebungClock.reset()  # clock
                frameN = -1
                continueRoutine = True
                routineTimer.add(1.130000)
                # update component parameters for each repeat
                pic_uebung.setImage('GoNoGo_stimuli/'+ picture)
                none_response_uebung = event.BuilderKeyResponse()
                # keep track of which components have finished
                stim_uebungComponents = [pic_uebung, none_response_uebung, image_key]
                for thisComponent in stim_uebungComponents:
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                
                # -------Start Routine "stim_uebung"-------
                while continueRoutine and routineTimer.getTime() > 0:
                    # get current time
                    t = stim_uebungClock.getTime()
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *pic_uebung* updates
                    if t >= 1.0 and pic_uebung.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        pic_uebung.tStart = t
                        pic_uebung.frameNStart = frameN  # exact frame index
                        pic_uebung.setAutoDraw(True)
                    frameRemains = 1.0 + 0.13- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if pic_uebung.status == STARTED and t >= frameRemains:
                        pic_uebung.setAutoDraw(False)
                    
                    # *image_key* updates
                    if t >= 0.0 and image_key.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        image_key.tStart = t
                        image_key.frameNStart = frameN  # exact frame index
                        image_key.setAutoDraw(True)
                    
                    # *none_response_uebung* updates
                    if t >= 0 and none_response_uebung.status == NOT_STARTED:
                        # keep track of start time/frame for later
                        none_response_uebung.tStart = t
                        none_response_uebung.frameNStart = frameN  # exact frame index
                        none_response_uebung.status = STARTED
                        # keyboard checking is just starting
                        win.callOnFlip(none_response_uebung.clock.reset)  # t=0 on next screen flip
                        event.clearEvents(eventType='keyboard')
                    frameRemains = 1 + 0.13- win.monitorFramePeriod * 0.75  # most of one frame period left
                    if none_response_uebung.status == STARTED and t >= frameRemains:
                        none_response_uebung.status = STOPPED
                    if none_response_uebung.status == STARTED:
                        theseKeys = event.getKeys(keyList=['none', 'down'])
                        
                        # check for quit:
                        if "escape" in theseKeys:
                            endExpNow = True
                        if len(theseKeys) > 0:  # at least one key was pressed
                            none_response_uebung.keys = theseKeys[0]  # storing the first key
                            none_response_uebung.rt.append(none_response_uebung.clock.getTime())
                            continueRoutine = True
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in stim_uebungComponents:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # check for quit (the Esc key)
                    if endExpNow or event.getKeys(keyList=["escape"]):
                        core.quit()
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                # -------Ending Routine "stim_uebung"-------
                for thisComponent in stim_uebungComponents:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # check responses
                if none_response_uebung.keys in ['', [], None]:  # No response was made
                    none_response_uebung.keys=None
                    # was no response the correct answer?!
                    none_response_uebung.corr = 1  # correct non-response
                else:
                    none_response_uebung.corr = 0  # failed to respond (incorrectly)
                # store data for trial_uebung (TrialHandler)
                trial_uebung.addData('none_response_uebung.keys',none_response_uebung.keys)
                trial_uebung.addData('none_response_uebung.corr', none_response_uebung.corr)
                if none_response_uebung.keys != None:  # we had a response
                    trial_uebung.addData('none_response_uebung.rt', none_response_uebung.rt)
                thisExp.nextEntry()
                
            # completed 1 repeats of 'trial_uebung'

            # ------Prepare to start Routine "intertr_pause_uebung"-------
            t = 0
            intertr_pause_uebungClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.00000)
            # update component parameters for each repeat
            response_uebung = event.BuilderKeyResponse()
            # keep track of which components have finished
            intertr_pause_uebungComponents = [response_uebung, image_key]
            for thisComponent in intertr_pause_uebungComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "intertr_pause_uebung"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = intertr_pause_uebungClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_key* updates
                if t >= 0.0 and image_key.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    image_key.tStart = t
                    image_key.frameNStart = frameN  # exact frame index
                    image_key.setAutoDraw(True)
                
                # *response_uebung* updates
                if t >= 0.0 and response_uebung.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    response_uebung.tStart = t
                    response_uebung.frameNStart = frameN  # exact frame index
                    response_uebung.status = STARTED
                    # keyboard checking is just starting
                    win.callOnFlip(response_uebung.clock.reset)  # t=0 on next screen flip
                    event.clearEvents(eventType='keyboard')
                frameRemains = 0.0 + 2 - win.monitorFramePeriod * 0.75  # most of one frame period left
                if response_uebung.status == STARTED and t >= frameRemains:
                    response_uebung.status = STOPPED
                if response_uebung.status == STARTED:
                    theseKeys = event.getKeys(keyList=['none', 'down'])
                    
                    # check for quit:
                    if "escape" in theseKeys:
                        endExpNow = True
                    if len(theseKeys) > 0:  # at least one key was pressed
                        response_uebung.keys = theseKeys[0]  # just the first key pressed
                        response_uebung.rt = response_uebung.clock.getTime()
                        # was this 'correct'?
                        if (response_uebung.keys == str(button)) or (response_uebung.keys == button):
                            response_uebung.corr = 1
                        else:
                            response_uebung.corr = 0
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in intertr_pause_uebungComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "intertr_pause_uebung"-------
            for thisComponent in intertr_pause_uebungComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if response_uebung.keys in ['', [], None]:  # No response was made
                response_uebung.keys=None
                # was no response the correct answer?!
                if str(button).lower() == 'none':
                   response_uebung.corr = 1  # correct non-response
                else:
                   response_uebung.corr = 0  # failed to respond (incorrectly)
            # store data for pairs_uebung (TrialHandler)
            pairs_uebung.addData('response_uebung.keys',response_uebung.keys)
            pairs_uebung.addData('response_uebung.corr', response_uebung.corr)
            if response_uebung.keys != None:  # we had a response
                pairs_uebung.addData('response_uebung.rt', response_uebung.rt)
            thisExp.nextEntry()
            
        # completed 1 repeats of 'pairs_uebung'

        # ------Prepare to start Routine "feedback"-------
            t = 0
            feedbackClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(1.0)
            # update component parameters for each repeat
            if response_uebung.corr == 1 and response_uebung.keys == 'down':#stored on last run routine
                msg="GoNoGo_stimuli/thumbs-up.png"
            elif response_uebung.corr == 0:
                msg = "GoNoGo_stimuli/thumbs-down.png"
            else:
                msg="GoNoGo_stimuli/empty.png"
            feedback.setImage(msg)
            # keep track of which components have finished
            feedbackComponents = [feedback, image_key]
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "feedback"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = feedbackClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_key* updates
                if t >= 0.0 and image_key.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    image_key.tStart = t
                    image_key.frameNStart = frameN  # exact frame index
                    image_key.setAutoDraw(True)
                
                # *feedback* updates
                if t >= 0.0 and feedback.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    feedback.tStart = t
                    feedback.frameNStart = frameN  # exact frame index
                    feedback.setAutoDraw(True)
                frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
                if feedback.status == STARTED and t >= frameRemains:
                    feedback.setAutoDraw(False)
                    
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "feedback"-------
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            thisExp.nextEntry()
            

        # ------Prepare to start Routine "instr3"-------
        t = 0
        instr3Clock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        key_instruction3 = event.BuilderKeyResponse()
        # keep track of which components have finished
        instr3Components = [key_instruction3, image_instruction3]
        for thisComponent in instr3Components:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
                
        # -------Start Routine "instr3"-------
        while continueRoutine:
            # get current time
            t = instr3Clock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *key_instruction3* updates
            if t >= 0.0 and key_instruction3.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_instruction3.tStart = t
                key_instruction3.frameNStart = frameN  # exact frame index
                key_instruction3.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_instruction3.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            if key_instruction3.status == STARTED:
                theseKeys = event.getKeys(keyList=['down', 'r'])
                
                # check for quit:
            if len(theseKeys) > 0:  # at least one key was pressed
                    # a response ends the routine
                key_instruction3.keys = theseKeys[0]
                if (key_instruction3.keys == str('down')) or (key_instruction3.keys == 'down'):
                    didnt_get_the_task = False
                continueRoutine = False
            
            # *image_instruction3* updates
            if t >= 0.0 and image_instruction3.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_instruction3.tStart = t
                image_instruction3.frameNStart = frameN  # exact frame index
                image_instruction3.setAutoDraw(True)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in instr3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()

    # -------Ending Routine "instr3"-------
        for thisComponent in instr3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_instruction3.keys in ['', [], None]:  # No response was made
            key_instruction3.keys=None
        thisExp.addData('key_instruction3.keys',key_instruction3.keys)
        if key_instruction3.keys != None:  # we had a response
            thisExp.addData('key_instruction3.rt', key_instruction3.rt)
        thisExp.nextEntry()
        # the Routine "instr3" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()

# set up handler to look after randomisation of conditions etc
pairs_real = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('GoNoGo_blocks.xlsx'),
    seed=None, name='pairs_real')
thisExp.addLoop(pairs_real)  # add the loop to the experiment
thisPairs_real = pairs_real.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPairs_real.rgb)
if thisPairs_real != None:
    for paramName in thisPairs_real:
        exec('{} = thisPairs_real[paramName]'.format(paramName))

for thisPairs_real in pairs_real:
    currentLoop = pairs_real
    # abbreviate parameter names if possible (e.g. rgb = thisPairs_real.rgb)
    if thisPairs_real != None:
        for paramName in thisPairs_real:
            exec('{} = thisPairs_real[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    trial_real = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('GoNoGo_datageneration.xlsx', selection=rows),
        seed=None, name='trial_real')
    thisExp.addLoop(trial_real)  # add the loop to the experiment
    thisTrial_real = trial_real.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_real.rgb)
    if thisTrial_real != None:
        for paramName in thisTrial_real:
            exec('{} = thisTrial_real[paramName]'.format(paramName))
    
    for thisTrial_real in trial_real:
        currentLoop = trial_real
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_real.rgb)
        if thisTrial_real != None:
            for paramName in thisTrial_real:
                exec('{} = thisTrial_real[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "stim_real"-------
        t = 0
        stim_realClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        routineTimer.add(1.130000)
        # update component parameters for each repeat
        pic_real.setImage('GoNoGo_stimuli/' + picture)
        none_response_real = event.BuilderKeyResponse()
        # keep track of which components have finished
        stim_realComponents = [pic_real, none_response_real, image_key]
        for thisComponent in stim_realComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "stim_real"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = stim_realClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pic_real* updates
            if t >= 1 and pic_real.status == NOT_STARTED:
                # keep track of start time/frame for later
                pic_real.tStart = t
                pic_real.frameNStart = frameN  # exact frame index
                pic_real.setAutoDraw(True)
            frameRemains = 1 + 0.13- win.monitorFramePeriod * 0.75  # most of one frame period left
            if pic_real.status == STARTED and t >= frameRemains:
                pic_real.setAutoDraw(False)
            
            # *image_key* updates
            if t >= 0.0 and image_key.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_key.tStart = t
                image_key.frameNStart = frameN  # exact frame index
                image_key.setAutoDraw(True)
            
            # *none_response_real* updates
            if t >= 0 and none_response_real.status == NOT_STARTED:
                # keep track of start time/frame for later
                none_response_real.tStart = t
                none_response_real.frameNStart = frameN  # exact frame index
                none_response_real.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(none_response_real.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            frameRemains = 1 + 0.1- win.monitorFramePeriod * 0.75  # most of one frame period left
            if none_response_real.status == STARTED and t >= frameRemains:
                none_response_real.status = STOPPED
            if none_response_real.status == STARTED:
                theseKeys = event.getKeys(keyList=['none', 'down'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    none_response_real.keys.extend(theseKeys)  # storing all keys
                    none_response_real.rt.append(none_response_real.clock.getTime())
                    continueRoutine = True
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in stim_realComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "stim_real"-------
        for thisComponent in stim_realComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if none_response_real.keys in ['', [], None]:  # No response was made
            none_response_real.keys=None
            # was no response the correct answer?!
            none_response_real.corr = 1  # correct non-response
        else:
            none_response_real.corr = 0  # failed to respond (incorrectly)
        # store data for trial_real (TrialHandler)
        trial_real.addData('none_response_real.keys',none_response_real.keys)
        trial_real.addData('none_response_real.corr', none_response_real.corr)
        if none_response_real.keys != None:  # we had a response
            trial_real.addData('none_response_real.rt', none_response_real.rt)
        thisExp.nextEntry()
        
    # completed 1 repeats of 'trial_real'
    
    
    # ------Prepare to start Routine "intertr_pause_real"-------
    t = 0
    intertr_pause_realClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    response_real = event.BuilderKeyResponse()
    # keep track of which components have finished
    intertr_pause_realComponents = [image_key, response_real]
    for thisComponent in intertr_pause_realComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "intertr_pause_real"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = intertr_pause_realClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_key* updates
        if t >= 0.0 and image_key.status == NOT_STARTED:
            # keep track of start time/frame for later
            image_key.tStart = t
            image_key.frameNStart = frameN  # exact frame index
            image_key.setAutoDraw(True)
        
        # *response_real* updates
        if t >= 0.0 and response_real.status == NOT_STARTED:
            # keep track of start time/frame for later
            response_real.tStart = t
            response_real.frameNStart = frameN  # exact frame index
            response_real.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(response_real.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if response_real.status == STARTED and t >= frameRemains:
            response_real.status = STOPPED
        if response_real.status == STARTED:
            theseKeys = event.getKeys(keyList=['none', 'down'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                if response_real.keys == []:  # then this was the first keypress
                    response_real.keys = theseKeys[0]  # just the first key pressed
                    response_real.rt = response_real.clock.getTime()
                    # was this 'correct'?
                    if (response_real.keys == str(button)) or (response_real.keys == button):
                        response_real.corr = 1
                    else:
                        response_real.corr = 0
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in intertr_pause_realComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "intertr_pause_real"-------
    for thisComponent in intertr_pause_realComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if response_real.keys in ['', [], None]:  # No response was made
        response_real.keys=None
        # was no response the correct answer?!
        if str(button).lower() == 'none':
           response_real.corr = 1  # correct non-response
        else:
           response_real.corr = 0  # failed to respond (incorrectly)
    # store data for pairs_real (TrialHandler)
    pairs_real.addData('response_real.keys',response_real.keys)
    pairs_real.addData('response_real.corr', response_real.corr)
    if response_real.keys != None:  # we had a response
        pairs_real.addData('response_real.rt', response_real.rt)
    thisExp.nextEntry()
    
# completed 1 repeats of 'pairs_real'

# the Routine "instr_ende" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()
# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
#win.close()
#core.quit()
